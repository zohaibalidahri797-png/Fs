/**
 * Generate 2 premium photographic service-card images for the
 * Wichita Maid Service website:
 *   1. service-deep.jpg      — close-up detail of a deep clean (gloved hand
 *      detailing a gleaming faucet / tile grout / countertop with a
 *      microfiber cloth, sparkling surfaces, bright natural daylight)
 *   2. service-recurring.jpg — bright, freshly maintained, lived-in-but-tidy
 *      Wichita living room conveying a regularly cared-for home (plump sofa,
 *      neat coffee table + small plant, polished floor, soft daylight)
 *
 * Constraints learned from previous tasks:
 *  - z-ai-web-dev-sdk MUST run in backend (Bun/Node), never client-side.
 *  - size must be a multiple of 32 between 512 and 2880. Use 1152x864
 *    (NOT 1440x720 — 720 is not a multiple of 32).
 *  - The API returns JPEG bytes (base64-decoded) directly.
 *  - Brand palette: deep navy + professional teal + warm white + subtle
 *    aqua; avoid blue/indigo dominance. Soft natural daylight, premium
 *    real-estate photography style. No people / no cartoon / no 3D-people.
 */
import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';

const OUT_DIR = '/home/z/my-project/public/images';
const SIZE = '1152x864'; // valid: 1152 % 32 == 0, 864 % 32 == 0

type Job = {
  name: string;
  out: string;
  prompt: string;
};

const JOBS: Job[] = [
  {
    name: 'service-deep',
    out: `${OUT_DIR}/service-deep.jpg`,
    prompt:
      'Photorealistic premium close-up detail photograph of a professional deep clean happening in a residential bathroom or kitchen. A single gloved hand wearing a teal-nitrile or rubber cleaning glove gently wipes a gleaming chrome faucet / polished tile grout / marble countertop with a folded microfiber cloth. Tiny water droplets and a faint streak-free sparkle on the metal and stone, crystal-clear sparkling surfaces reflecting soft natural daylight from an off-camera window. Warm cream and warm white surfaces with subtle teal and sage-green accents in towels or trim. Shallow depth of field, sharp focus on the hand and cloth and the gleaming surface, background gently blurred. Warm but clean color grade, editorial-quality commercial cleaning photography, hyper-detailed, premium real-estate photography style, no faces, no cartoon, no 3D-rendered people, no blue or indigo dominance.',
  },
  {
    name: 'service-recurring',
    out: `${OUT_DIR}/service-recurring.jpg`,
    prompt:
      'Photorealistic premium real-estate photograph of a bright, freshly maintained, lived-in-but-tidy Wichita living room that conveys a regularly cared-for home. A plump, neatly arranged sofa with clean cream and warm white upholstery and a couple of soft sage-green and teal accent pillows, a neat low coffee table with a small healthy potted plant, a tidy stack of books, a folded throw blanket. Gleaming polished warm hardwood floor reflecting soft natural daylight from tall windows with sheer curtains. Subtle sense of "kept up weekly" — comfortable, consistent, calm, well-cared-for. Warm cream walls with subtle teal and gold accents, a few tasteful neutral decorative objects. Wide-angle architectural interior photography, shallow depth of field, warm but clean color grade, golden-hour light, hyper-detailed, editorial quality, no people, no cartoon, no 3D-people, no blue or indigo dominance.',
  },
];

async function generateOne(
  zai: Awaited<ReturnType<typeof ZAI.create>>,
  job: Job,
): Promise<{ name: string; ok: boolean; bytes?: number; error?: string; attempts: number }> {
  // Per task spec: retry up to 2 times then move on (initial + 2 retries = 3 attempts)
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      console.log(`[${job.name}] attempt ${attempt}/3 size=${SIZE}`);
      const resp = await zai.images.generations.create({
        prompt: job.prompt,
        size: SIZE,
      });
      const b64 = resp?.data?.[0]?.base64;
      if (!b64) throw new Error('no base64 in response');
      const buf = Buffer.from(b64, 'base64');
      if (!buf || buf.length < 1024) {
        throw new Error(`buffer too small: ${buf?.length ?? 0} bytes`);
      }
      fs.writeFileSync(job.out, buf);
      console.log(`[${job.name}] OK -> ${job.out} (${buf.length} bytes)`);
      return { name: job.name, ok: true, bytes: buf.length, attempts: attempt };
    } catch (e) {
      const msg = (e as Error)?.message ?? String(e);
      console.error(`[${job.name}] attempt ${attempt} failed: ${msg}`);
      if (attempt < 3) {
        await new Promise((r) => setTimeout(r, 1500 * attempt));
      } else {
        return { name: job.name, ok: false, error: msg, attempts: attempt };
      }
    }
  }
  return { name: job.name, ok: false, error: 'unreachable', attempts: 3 };
}

async function main() {
  if (!fs.existsSync(OUT_DIR)) {
    fs.mkdirSync(OUT_DIR, { recursive: true });
  }

  const zai = await ZAI.create();
  const results: { name: string; ok: boolean; bytes?: number; error?: string; attempts: number }[] = [];

  for (const job of JOBS) {
    const r = await generateOne(zai, job);
    results.push(r);
  }

  console.log('\n=== SUMMARY ===');
  for (const r of results) {
    if (r.ok) {
      console.log(`\u2713 ${r.name}: ${r.bytes} bytes (attempts=${r.attempts})`);
    } else {
      console.error(`\u2717 ${r.name}: FAILED after ${r.attempts} attempts — ${r.error}`);
    }
  }

  const failures = results.filter((r) => !r.ok);
  if (failures.length > 0) {
    console.error(`\n${failures.length} image(s) failed.`);
  } else {
    console.log('\nAll images generated successfully.');
  }
}

main().catch((e) => {
  console.error('Fatal error in main:', e);
  process.exit(1);
});
