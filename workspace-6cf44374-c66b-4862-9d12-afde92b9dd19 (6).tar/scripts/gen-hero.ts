/**
 * Regenerate just the hero image with a valid size (1344x768).
 * The 1440x720 size from SKILL.md is actually rejected by the API because
 * 720 is not a multiple of 32 (API rule: width/height must be multiples of 32,
 * between 512-2880, max 2^22 pixels).
 */
import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';

const OUT = '/home/z/my-project/public/images/hero-cleaning.jpg';
const SIZE = '1344x768';

const PROMPT =
  'Wide bright airy modern home interior, open-plan living room flowing into a contemporary kitchen, bathed in warm natural sunlight streaming through tall windows, gleaming spotless surfaces, fresh and inviting atmosphere, polished hardwood floors, neutral cream and warm white tones with soft sage-green accents. A friendly professional house cleaner in a clean crisp uniform (teal-green apron over cream shirt) smiling warmly, standing off to the right side holding professional cleaning supplies and a microfiber cloth. Premium architectural real-estate photography, shallow depth of field, warm but clean color grade, golden-hour light, hyper-detailed, photorealistic, editorial quality, no blue tones.';

async function main() {
  const zai = await ZAI.create();
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      console.log(`hero attempt ${attempt}/3 size=${SIZE}`);
      const resp = await zai.images.generations.create({
        prompt: PROMPT,
        size: SIZE,
      });
      const b64 = resp?.data?.[0]?.base64;
      if (!b64) throw new Error('no base64 in response');
      const buf = Buffer.from(b64, 'base64');
      fs.writeFileSync(OUT, buf);
      console.log(`hero OK -> ${OUT} (${buf.length} bytes)`);
      return;
    } catch (e) {
      console.error(`hero attempt ${attempt} failed:`, (e as Error)?.message ?? e);
      await new Promise((r) => setTimeout(r, 1500 * attempt));
    }
  }
  console.error('hero FAILED after 3 attempts');
  process.exit(1);
}

main();
