/**
 * Generate premium cleaning-service website images.
 *
 * Uses z-ai-web-dev-sdk (backend only) per the image-generation SKILL.md.
 * Run: `bun run scripts/gen-images.ts`
 *
 * Outputs 6 images into /home/z/my-project/public/images/
 */
import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import path from 'path';

const OUT_DIR = '/home/z/my-project/public/images';

type Job = {
  filename: string;
  prompt: string;
  size: string;
};

const JOBS: Job[] = [
  {
    filename: 'hero-cleaning.jpg',
    size: '1440x720',
    prompt:
      'Wide bright airy modern home interior, open-plan living room flowing into a contemporary kitchen, bathed in warm natural sunlight streaming through tall windows, gleaming spotless surfaces, fresh and inviting atmosphere, polished hardwood floors, neutral cream and warm white tones with soft sage-green accents. A friendly professional house cleaner in a clean crisp uniform (teal-green apron over cream shirt) smiling warmly, standing off to the right side holding professional cleaning supplies and a microfiber cloth. Premium architectural real-estate photography, shallow depth of field, warm but clean color grade, golden-hour light, hyper-detailed, photorealistic, editorial quality, no blue tones.',
  },
  {
    filename: 'residential-home.jpg',
    size: '864x1152',
    prompt:
      'A beautifully clean, sunlit residential living room just after a professional deep clean. Plush cream-colored sofa with soft throw pillows, tidy wooden coffee table with a small vase of fresh white flowers, polished warm hardwood floor, large windows letting in soft natural daylight, sheer curtains gently lit. Warm welcoming premium real-estate photography, warm cream and soft sage-green palette, no people, photorealistic, editorial magazine quality, soft natural light, no blue tones.',
  },
  {
    filename: 'commercial-office.jpg',
    size: '1152x864',
    prompt:
      'A spotless modern open-plan office after professional cleaning. Rows of clean minimalist desks with organized monitors, gleaming glass partitions, polished concrete and hardwood floors reflecting soft daylight from floor-to-ceiling windows. Bright, premium corporate architectural photography, warm cream and neutral tones with subtle sage-green accents, no people or just a hint of a professional figure far in the background, photorealistic, editorial quality, soft natural daylight, no blue-dominant tones.',
  },
  {
    filename: 'before-messy.jpg',
    size: '1152x864',
    prompt:
      'A realistically cluttered and slightly dusty residential living room before a professional cleaning service. Plush cream sofa with disorganized cushions and a folded throw blanket, wooden coffee table with a few scattered mugs, magazines and remote controls, light visible dust on surfaces, slightly dull overcast daylight through large windows, sheer curtains half drawn. Same room layout and color palette as a matching after-clean image. Photorealistic, not exaggerated, lived-in but not disastrous, warm cream tones, no people, editorial quality, no blue tones.',
  },
  {
    filename: 'after-clean.jpg',
    size: '1152x864',
    prompt:
      'The exact same residential living room as a paired before image, now spotless and professionally deep-cleaned. Plush cream sofa neatly arranged with straightened cushions and folded throw blanket, bare polished wooden coffee table with a single small vase of fresh white flowers, gleaming dust-free surfaces, polished warm hardwood floor, bright fresh daylight pouring through large windows, sheer curtains fully open. Warm cream and soft sage-green palette, photorealistic, premium real-estate photography, editorial quality, no people, no blue tones.',
  },
  {
    filename: 'about-team.jpg',
    size: '1152x864',
    prompt:
      'A friendly professional small local house-cleaning team of two to three people, a mix of ages and ethnicities, in clean crisp teal-green aprons over cream uniforms, smiling warmly and genuinely at the camera, standing in a bright clean sunlit home living room. One holds a cleaning caddy with spray bottles and microfiber cloths, another holds a fresh white flower, the third has a friendly relaxed posture. Conveys family-business trust, warmth, and professionalism. Premium editorial photography, warm natural light, shallow depth of field, warm cream tones with sage-green accents, photorealistic, authentic expressions not stock-photo-cheesy, no blue-dominant tones.',
  },
];

async function generateOne(
  zai: Awaited<ReturnType<typeof ZAI.create>>,
  job: Job,
  maxAttempts = 3
): Promise<{ ok: boolean; bytes?: number; error?: string }> {
  let lastErr: unknown;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      console.log(
        `[${job.filename}] attempt ${attempt}/${maxAttempts} size=${job.size}`
      );
      const resp = await zai.images.generations.create({
        prompt: job.prompt,
        size: job.size,
      });
      const data = resp?.data?.[0];
      const b64 = data?.base64;
      if (!b64 || typeof b64 !== 'string') {
        throw new Error('No base64 in response');
      }
      const buf = Buffer.from(b64, 'base64');
      const outPath = path.join(OUT_DIR, job.filename);
      fs.writeFileSync(outPath, buf);
      console.log(
        `[${job.filename}] OK -> ${outPath} (${buf.length} bytes, attempt ${attempt})`
      );
      return { ok: true, bytes: buf.length };
    } catch (e) {
      lastErr = e;
      console.error(`[${job.filename}] attempt ${attempt} failed:`, (e as Error)?.message ?? e);
      // brief backoff
      await new Promise((r) => setTimeout(r, 1500 * attempt));
    }
  }
  return { ok: false, error: (lastErr as Error)?.message ?? 'unknown error' };
}

async function main() {
  if (!fs.existsSync(OUT_DIR)) {
    fs.mkdirSync(OUT_DIR, { recursive: true });
  }
  const zai = await ZAI.create();
  const results: Array<{ filename: string; ok: boolean; bytes?: number; error?: string }> = [];
  for (const job of JOBS) {
    const r = await generateOne(zai, job);
    results.push({ filename: job.filename, ...r });
  }
  console.log('\n========== SUMMARY ==========');
  let okCount = 0;
  for (const r of results) {
    if (r.ok) {
      okCount++;
      console.log(`  OK   ${r.filename}  (${r.bytes} bytes)`);
    } else {
      console.log(`  FAIL ${r.filename}  (${r.error})`);
    }
  }
  console.log(`\nGenerated ${okCount}/${results.length} images.`);
}

main().catch((e) => {
  console.error('Fatal:', e);
  process.exit(1);
});
