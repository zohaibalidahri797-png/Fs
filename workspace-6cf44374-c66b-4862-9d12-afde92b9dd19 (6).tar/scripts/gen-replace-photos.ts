/**
 * Task: fix-photos
 * Generate 3 premium photographic images that contain NO people, NO hands,
 * NO human figures whatsoever — only interiors, surfaces, and objects.
 *
 * This replaces the previously AI-generated images that included:
 *   - hero-cleaning.jpg   (had an AI cleaner person in the hero)
 *   - about-team.jpg        (had an AI team of people in the About section)
 *   - service-deep.jpg     (had a gloved hand in the Deep Cleaning card)
 *
 * Uses z-ai-web-dev-sdk in a backend Bun script (per skill requirements).
 * Sizes must be multiples of 32 between 512 and 2880:
 *   - 1344x768 (wide landscape 16:9-ish) for the hero
 *   - 1152x864 (landscape 4:3) for the other two
 *
 * Brand palette: warm premium real-estate photography, soft natural daylight,
 * clean whites, subtle teal/sage. AVOID blue/indigo dominance. NO cartoon,
 * NO 3D-render look. NO people / hands / human figures.
 *
 * Retry: up to 3 attempts per image (1 initial + 2 retries) then move on.
 */
import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';

type Spec = {
  out: string;
  size: '1344x768' | '1152x864';
  prompt: string;
  label: string;
};

const SPECS: Spec[] = [
  {
    label: 'hero-cleaning',
    out: '/home/z/my-project/public/images/hero-cleaning.jpg',
    size: '1344x768',
    prompt:
      'Wide, bright, airy, premium spotless modern home interior: an open-plan living room flowing into a clean contemporary kitchen, bathed in warm natural sunlight streaming through large windows, gleaming polished hardwood floors, plush cream-colored sofa, tidy pristine surfaces, fresh subtle greenery and a small vase of white flowers. Absolutely no people, no human figures, no hands, no faces — interior only. Premium architectural real-estate photography, shallow depth of field, warm but clean color grade, soft natural daylight, neutral cream and warm whites with subtle sage-green accents, hyper-detailed, photorealistic, editorial quality, landscape 16:9 composition, no blue tones, no cartoon, no 3D render.',
  },
  {
    label: 'about-team',
    out: '/home/z/my-project/public/images/about-team.jpg',
    size: '1152x864',
    prompt:
      'A bright, spotless, sunlit modern kitchen interior just after a professional clean: gleaming white marble countertops, polished chrome fixtures, organized and pristine, a few subtle green plants on the windowsill, warm natural daylight pouring in, soft reflections on spotless surfaces, sense of a well-cared-for home. Absolutely no people, no human hands, no human figures, no faces — interior only. Premium real-estate photography, warm-clean color tone, neutral cream and warm whites with subtle sage accents, shallow depth of field, photorealistic, editorial quality, landscape 4:3 composition, no blue tones, no cartoon, no 3D render.',
  },
  {
    label: 'service-deep',
    out: '/home/z/my-project/public/images/service-deep.jpg',
    size: '1152x864',
    prompt:
      'Close-up detail of a sparkling clean, gleaming modern white marble kitchen countertop and a polished stainless steel faucet, fresh water droplets catching bright daylight, polished mirror-like surfaces, a few clean microfiber cloths neatly folded nearby, bright fresh natural daylight. Absolutely no people, no human hands, no human figures, no fingers, no faces — surfaces and objects only. Premium macro/detail product photography, warm-clean color tone, neutral cream and warm whites with subtle sage accents, shallow depth of field, photorealistic, editorial quality, landscape 4:3 composition, no blue tones, no cartoon, no 3D render.',
  },
];

async function generateOne(zai: any, spec: Spec): Promise<{ ok: boolean; bytes: number; attempts: number; error?: string }> {
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      console.log(`[${spec.label}] attempt ${attempt}/3 size=${spec.size}`);
      const resp = await zai.images.generations.create({
        prompt: spec.prompt,
        size: spec.size,
      });
      const b64 = resp?.data?.[0]?.base64;
      if (!b64) throw new Error('no base64 in response');
      const buf = Buffer.from(b64, 'base64');
      if (!buf || buf.length < 1024) throw new Error(`buffer too small: ${buf?.length ?? 0} bytes`);
      fs.writeFileSync(spec.out, buf);
      console.log(`[${spec.label}] OK -> ${spec.out} (${buf.length} bytes)`);
      return { ok: true, bytes: buf.length, attempts: attempt };
    } catch (e) {
      const msg = (e as Error)?.message ?? String(e);
      console.error(`[${spec.label}] attempt ${attempt} failed: ${msg}`);
      if (attempt < 3) {
        await new Promise((r) => setTimeout(r, 1500 * attempt));
      } else {
        return { ok: false, bytes: 0, attempts: attempt, error: msg };
      }
    }
  }
  return { ok: false, bytes: 0, attempts: 3, error: 'exhausted retries' };
}

async function main() {
  console.log('=== gen-replace-photos: starting (no-people images) ===');
  const zai = await ZAI.create();
  const results: { label: string; out: string; size: string; ok: boolean; bytes: number; attempts: number; error?: string }[] = [];
  for (const spec of SPECS) {
    const r = await generateOne(zai, spec);
    results.push({ label: spec.label, out: spec.out, size: spec.size, ...r });
  }
  console.log('\n=== SUMMARY ===');
  for (const r of results) {
    const status = r.ok ? `OK (${r.bytes} bytes, ${r.attempts} attempt(s))` : `FAILED (${r.error})`;
    console.log(`- ${r.label} [${r.size}] -> ${r.out}: ${status}`);
  }
  const failed = results.filter((r) => !r.ok);
  if (failed.length) {
    console.error(`\n${failed.length} image(s) failed; see above.`);
  } else {
    console.log('\nAll 3 images generated successfully.');
  }
}

main().catch((e) => {
  console.error('Fatal error in gen-replace-photos:', e);
  process.exit(1);
});
