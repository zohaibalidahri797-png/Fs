/**
 * Generate 2 premium photographic service-card images for the
 * Wichita Maid Service website:
 *   1. service-move-in-out.jpg   — empty, freshly cleaned home interior
 *      conveying a move-in/move-out moment, with subtle stacked moving boxes
 *   2. service-post-construction.jpg — interior AFTER post-construction
 *      cleaning: polished floor, dust-free fixtures, hints of tools set aside
 *
 * Constraints learned from previous tasks:
 *  - z-ai-web-dev-sdk MUST run in backend (Bun/Node), never client-side.
 *  - size must be a multiple of 32 between 512 and 2880. Use 1152x864
 *    (NOT 1440x720 — 720 is not a multiple of 32).
 *  - The API returns JPEG bytes (base64-decoded) directly.
 *  - Brand palette: deep teal-green + warm cream + soft gold; avoid
 *    blue/indigo dominance. Soft natural daylight, premium real-estate
 *    photography style. No people.
 */
import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';

const OUT_DIR = '/home/z/my-project/public/images';
const SIZE = '1152x864'; // valid: 1152 % 32 == 0, 864 % 32 == 0

type Job = {
  name: string;
  out: string;
  prompt: string;
};

const JOBS: Job[] = [
  {
    name: 'service-move-in-out',
    out: `${OUT_DIR}/service-move-in-out.jpg`,
    prompt:
      'Photorealistic premium real-estate photograph of a spotless, completely EMPTY residential home interior conveying a move-in or move-out moment. An airy open-plan living room with completely clear, gleaming surfaces, freshly polished warm hardwood floors reflecting soft natural daylight, tall windows with sheer curtains letting warm morning sunlight pour in, neutral warm cream and soft white walls, subtle sage-green and warm gold accents. A few neatly stacked cardboard moving boxes along one far wall — subtle, tidy, not cluttered. A sense of a fresh start and a brand-new clean home. Wide-angle architectural interior photography, shallow depth of field, warm but clean color grade, golden-hour light, hyper-detailed, editorial quality, no people, no blue or indigo tones, no cartoon styling.',
  },
  {
    name: 'service-post-construction',
    out: `${OUT_DIR}/service-post-construction.jpg`,
    prompt:
      'Photorealistic premium photograph of a residential or commercial interior AFTER professional post-construction cleaning. Dust-free polished surface — polished concrete or glossy hardwood floor reflecting clean daylight, flawless fresh drywall in warm white and cream tones, gleaming stainless-steel fixtures and large windows completely free of construction dust, soft sage-green and warm gold accents in fixtures and trim. In the far background, a hint of neatly set-aside renovation tools or neatly stacked building materials — subtle, organized, not the focus of the image. Bright clean natural daylight from large windows. Conveys "dust and debris removed, truly move-in ready." Wide-angle architectural interior photography, shallow depth of field, warm but clean color grade, hyper-detailed, editorial quality, no people, no blue or indigo tones, no cartoon styling.',
  },
];

async function generateOne(
  zai: Awaited<ReturnType<typeof ZAI.create>>,
  job: Job,
): Promise<{ name: string; ok: boolean; bytes?: number; error?: string; attempts: number }> {
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      console.log(`[${job.name}] attempt ${attempt}/3 size=${SIZE}`);
      const resp = await zai.images.generations.create({
        prompt: job.prompt,
        size: SIZE,
      });
      const b64 = resp?.data?.[0]?.base64;
      if (!b64) throw new Error('no base64 in response');
      const buf = Buffer.from(b64, 'base64');
      if (!buf || buf.length < 1024) {
        throw new Error(`buffer too small: ${buf?.length ?? 0} bytes`);
      }
      fs.writeFileSync(job.out, buf);
      console.log(`[${job.name}] OK -> ${job.out} (${buf.length} bytes)`);
      return { name: job.name, ok: true, bytes: buf.length, attempts: attempt };
    } catch (e) {
      const msg = (e as Error)?.message ?? String(e);
      console.error(`[${job.name}] attempt ${attempt} failed: ${msg}`);
      if (attempt < 3) {
        await new Promise((r) => setTimeout(r, 1500 * attempt));
      } else {
        return { name: job.name, ok: false, error: msg, attempts: attempt };
      }
    }
  }
  return { name: job.name, ok: false, error: 'unreachable', attempts: 3 };
}

async function main() {
  if (!fs.existsSync(OUT_DIR)) {
    fs.mkdirSync(OUT_DIR, { recursive: true });
  }

  const zai = await ZAI.create();
  const results: { name: string; ok: boolean; bytes?: number; error?: string; attempts: number }[] = [];

  for (const job of JOBS) {
    const r = await generateOne(zai, job);
    results.push(r);
  }

  console.log('\n=== SUMMARY ===');
  for (const r of results) {
    if (r.ok) {
      console.log(`✓ ${r.name}: ${r.bytes} bytes (attempts=${r.attempts})`);
    } else {
      console.error(`✗ ${r.name}: FAILED after ${r.attempts} attempts — ${r.error}`);
    }
  }

  const failures = results.filter((r) => !r.ok);
  if (failures.length > 0) {
    console.error(`\n${failures.length} image(s) failed.`);
  } else {
    console.log('\nAll images generated successfully.');
  }
}

main().catch((e) => {
  console.error('Fatal error in main:', e);
  process.exit(1);
});
