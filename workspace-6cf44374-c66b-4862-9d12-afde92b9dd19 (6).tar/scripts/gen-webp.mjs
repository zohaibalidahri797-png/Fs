import sharp from "sharp";
import { readdir } from "node:fs/promises";
import { join } from "node:path";

const dir = "public/images";
const files = (await readdir(dir)).filter((f) => /\.(jpe?g|png)$/i.test(f));
for (const f of files) {
  const src = join(dir, f);
  const out = join(dir, f.replace(/\.(jpe?g|png)$/i, ".webp"));
  await sharp(src, { failOn: "none" })
    .rotate()
    .resize({ width: 1600, withoutEnlargement: true })
    .webp({ quality: 78 })
    .toFile(out);
  const orig = (await stat(src)).size;
  const neo = (await stat(out)).size;
  console.log(`${f} -> webp  ${orig} -> ${neo} bytes (${Math.round((1 - neo / orig) * 100)}% smaller)`);
}
async function stat(p) {
  const { stat } = await import("node:fs/promises");
  return stat(p);
}
