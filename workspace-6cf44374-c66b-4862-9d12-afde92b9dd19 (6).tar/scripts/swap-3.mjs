import sharp from "sharp";
import fs from "node:fs/promises";
const swaps = [
  ["/tmp/r-kitchen.jpg", "public/images/about-team.jpg"],
  ["/tmp/r-living.jpg", "public/images/residential-home.jpg"],
  ["/tmp/r-office.jpg", "public/images/commercial-office.jpg"],
];
for (const [src, dest] of swaps) {
  await sharp(src, { failOn: "none" }).rotate()
    .resize({ width: 1600, withoutEnlargement: true })
    .jpeg({ quality: 80, mozjpeg: true })
    .toFile(dest);
  console.log("swapped", dest);
}
