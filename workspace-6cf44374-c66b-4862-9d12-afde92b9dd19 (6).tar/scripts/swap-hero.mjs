import sharp from "sharp";
await sharp("/tmp/hero-real.jpg", { failOn: "none" })
  .rotate()
  .resize({ width: 1600, withoutEnlargement: true })
  .jpeg({ quality: 80, mozjpeg: true })
  .toFile("/tmp/hero-opt.jpg");
// overwrite
const fs = await import("node:fs/promises");
await fs.copyFile("/tmp/hero-opt.jpg", "public/images/hero-cleaning.jpg");
console.log("hero swapped");
