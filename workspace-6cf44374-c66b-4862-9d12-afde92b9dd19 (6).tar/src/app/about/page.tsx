import type { Metadata } from "next";
import { PageLayout, PageCta } from "@/components/site/page-shell";
import { About } from "@/components/site/about";
import { Commitment } from "@/components/site/commitment";

export const metadata: Metadata = {
  title: "About Clean Maid USA LLC",
  description:
    "Wichita Maid Service® | Clean Maid USA LLC is a local, family-owned cleaning company founded in Wichita, Kansas in 2008. Residential and commercial cleaning built on honesty, reliability, and long-term relationships.",
  alternates: { canonical: "/about" },
  openGraph: {
    title: "About Wichita Maid Service® | Clean Maid USA LLC",
    description:
      "A local, family-owned Wichita cleaning company since 2008. Built on honesty, reliability, and long-term customer relationships.",
  },
};

export default function AboutPage() {
  return (
    <PageLayout
      eyebrow="About"
      title={
        <>
          A Wichita family business{" "}
          <span className="text-gradient-brand">built on relationships</span>
        </>
      }
      intro="Founded in Wichita, Kansas in 2008 — a local, family-owned cleaning company delivering professional residential and commercial cleaning, one relationship at a time."
    >
      <About showHeading={false} />
      <Commitment />
      <PageCta
        title="Work with a local team you can trust"
        copy="Get a free, personalized quote from our Wichita team — for your home or your business."
      />
    </PageLayout>
  );
}
