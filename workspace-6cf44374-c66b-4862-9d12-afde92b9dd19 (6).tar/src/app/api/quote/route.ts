import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";

function isEmail(v: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
}

const SERVICE_OPTIONS = new Set([
  "Residential Cleaning",
  "Office & Commercial Cleaning",
  "Move-In / Move-Out Cleaning",
  "Post-Construction Cleaning",
  "Deep Cleaning",
  "Recurring Cleaning",
  "Customized Cleaning Services",
  "Not sure yet — help me decide",
]);

const PROPERTY_OPTIONS = new Set([
  "Single-family home",
  "Apartment / Condo",
  "Townhome",
  "Office / Workspace",
  "Retail / Commercial",
  "Other",
]);

const TIME_OPTIONS = new Set([
  "Morning",
  "Afternoon",
  "Evening",
  "Anytime",
  "After-hours",
]);

export async function POST(req: NextRequest) {
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  const get = (k: string) => String(body?.[k] ?? "").trim();

  const name = get("name");
  const phone = get("phone");
  const email = get("email");
  const service = get("service");
  const propertyType = get("propertyType");
  const preferredDate = get("preferredDate");
  const preferredTime = get("preferredTime");
  const propertySize = get("propertySize");
  const message = get("message").slice(0, 4000);

  const errors: Record<string, string> = {};
  if (!name) errors.name = "Name is required.";
  if (!phone) errors.phone = "Phone is required.";
  if (!email) errors.email = "Email is required.";
  else if (!isEmail(email)) errors.email = "A valid email is required.";
  if (!service) errors.service = "Please choose a service.";
  else if (!SERVICE_OPTIONS.has(service)) errors.service = "Unknown service.";
  if (!propertyType) errors.propertyType = "Please choose a property type.";
  else if (!PROPERTY_OPTIONS.has(propertyType))
    errors.propertyType = "Unknown property type.";
  if (preferredTime && !TIME_OPTIONS.has(preferredTime))
    errors.preferredTime = "Unknown time preference.";
  if (preferredDate && Number.isNaN(Date.parse(preferredDate)))
    errors.preferredDate = "Invalid date.";

  if (Object.keys(errors).length > 0) {
    return NextResponse.json({ error: "Validation failed", fields: errors }, { status: 422 });
  }

  // No database required — this marketing site is static-hosting friendly.
  // In production, forward this submission to your form/CRM provider
  // (e.g. Web3Forms, Formspree, Google Sheets, or a CRM webhook).
  console.log("[Quote Request]", {
    name,
    phone,
    email,
    service,
    propertyType,
    preferredDate: preferredDate || null,
    preferredTime: preferredTime || null,
    propertySize: propertySize || null,
    message: message || null,
    receivedAt: new Date().toISOString(),
  });

  return NextResponse.json(
    { ok: true, message: "Quote request received." },
    { status: 201 },
  );
}

export async function GET() {
  return NextResponse.json({
    service: "Wichita Maid Service® | Clean Maid USA LLC",
    endpoint: "POST /api/quote",
    fields: [
      "name",
      "phone",
      "email",
      "service",
      "propertyType",
      "preferredDate",
      "preferredTime",
      "propertySize",
      "message",
    ],
  });
}
