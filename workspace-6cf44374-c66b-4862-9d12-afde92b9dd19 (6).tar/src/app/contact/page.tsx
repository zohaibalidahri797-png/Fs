import type { Metadata } from "next";
import { PageLayout } from "@/components/site/page-shell";
import { QuoteForm } from "@/components/site/quote-form";

export const metadata: Metadata = {
  title: "Contact & Get a Free Quote",
  description:
    "Contact Wichita Maid Service® | Clean Maid USA LLC for a free, personalized cleaning quote. Call (316) 477-0101 or email CleanMaidUS@gmail.com. Serving Wichita, KS and surrounding areas since 2008.",
  alternates: { canonical: "/contact" },
  openGraph: {
    title: "Contact & Get a Free Quote | Wichita Maid Service®",
    description:
      "Request a free cleaning quote or call (316) 477-0101. Insured, background-checked, family-owned — serving Wichita, KS since 2008.",
  },
};

export default function ContactPage() {
  return (
    <PageLayout
      eyebrow="Contact"
      title={
        <>
          Get your free, personalized{" "}
          <span className="text-gradient-brand">cleaning quote</span>
        </>
      }
      intro="Tell us about your space and what matters most to you. We'll walk it with you, build a cleaning plan around your needs, and send a clear, no-obligation quote."
    >
      <QuoteForm showHeading={false} />
    </PageLayout>
  );
}
