import type { Metadata } from "next";
import { PageLayout, PageCta } from "@/components/site/page-shell";
import { LegalContent } from "@/components/site/legal";

export const metadata: Metadata = {
  title: "Disclaimer",
  description:
    "Disclaimer for the Wichita Maid Service® | Clean Maid USA LLC website — general information, service availability, estimates, and illustrative imagery.",
  alternates: { canonical: "/disclaimer" },
};

export default function DisclaimerPage() {
  return (
    <PageLayout
      eyebrow="Legal"
      title="Disclaimer"
      intro="The information on this website is provided for general purposes. Please review the points below."
    >
      <LegalContent
        items={[
          {
            h: "General information",
            p: [
              "Information on this website is provided for general informational purposes about Wichita Maid Service® | Clean Maid USA LLC and our cleaning services. It is not intended as professional advice or a binding offer of service.",
            ],
          },
          {
            h: "No warranties",
            p: [
              "Information is provided \"as is\" without warranties of any kind, express or implied, to the extent permitted by law.",
            ],
          },
          {
            h: "Service availability and scheduling",
            p: [
              "Cleaning services and scheduling are subject to current availability and capacity. Same-day service is offered only when the schedule allows, and is not guaranteed.",
            ],
          },
          {
            h: "Estimates and pricing",
            p: [
              "Quotes provided through this website are estimates based on the information you share. Final scope and pricing are confirmed before service and may differ from an initial estimate if conditions vary.",
            ],
          },
          {
            h: "Illustrative imagery",
            p: [
              "Some images on this website are illustrative or representative photography used to show the type of work we do. They may not depict specific client projects or exact results, and your results may vary depending on your space and its condition.",
            ],
          },
          {
            h: "Third-party content",
            p: [
              "This website may display or link to third-party content (such as Google Maps and Google Reviews). We are not responsible for the accuracy or content of third-party information.",
            ],
          },
          {
            h: "Contact us",
            p: [
              "If you have questions, contact us at CleanMaidUS@gmail.com or (316) 477-0101. Mailing address: 1020 East English Street, Suite A1, Wichita, KS 67211.",
            ],
          },
        ]}
      />
      <p className="pb-10 text-center text-xs text-muted-foreground">
        Last updated: {new Date().getFullYear()}
      </p>
      <PageCta />
    </PageLayout>
  );
}
