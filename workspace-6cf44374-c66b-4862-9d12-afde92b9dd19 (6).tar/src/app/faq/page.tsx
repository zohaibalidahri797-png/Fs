import type { Metadata } from "next";
import { PageLayout, PageCta } from "@/components/site/page-shell";
import { Faq } from "@/components/site/faq";
import { FAQS } from "@/components/site/faq-data";

export const metadata: Metadata = {
  title: "FAQ — Cleaning Service Questions Answered",
  description:
    "Answers to common questions about Wichita Maid Service® — service areas, background-checked & insured cleaners, recurring plans, deep vs. regular cleaning, same-day availability, pricing, and how to get a free quote.",
  alternates: { canonical: "/faq" },
  openGraph: {
    title: "FAQ | Wichita Maid Service® | Clean Maid USA LLC",
    description:
      "Answers to common cleaning-service questions for Wichita homes and businesses.",
  },
};

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: FAQS.map((f) => ({
    "@type": "Question",
    name: f.q,
    acceptedAnswer: { "@type": "Answer", text: f.a },
  })),
};

export default function FaqPage() {
  return (
    <PageLayout
      eyebrow="FAQ"
      title={
        <>
          Answers to{" "}
          <span className="text-gradient-brand">common questions</span>
        </>
      }
      intro="Everything you need to know about working with us. Can't find your answer? We're a quick call away at (316) 477-0101."
    >
      <Faq showHeading={false} />
      <PageCta />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />
    </PageLayout>
  );
}
