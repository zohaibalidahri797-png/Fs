import type { Metadata } from "next";
import { Inter, Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const jakarta = Plus_Jakarta_Sans({
  variable: "--font-jakarta",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800"],
  display: "swap",
});

const SITE_URL = "https://cleanmaidusa.com";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default:
      "Wichita Maid Service® | Clean Maid USA LLC — Professional Cleaning in Wichita, KS",
    template:
      "%s | Wichita Maid Service® | Clean Maid USA LLC",
  },
  description:
    "Professional residential & commercial cleaning serving Wichita, Kansas and surrounding areas since 2008. Insured, background-checked, family-owned. Residential, commercial, move-in/move-out & post-construction cleaning. Get a free quote.",
  keywords: [
    "Wichita maid service",
    "house cleaning Wichita KS",
    "office cleaning Wichita",
    "move in move out cleaning Wichita",
    "post construction cleaning Wichita",
    "commercial cleaning Wichita",
    "insured cleaning Wichita",
    "Clean Maid USA",
    "family owned cleaning Wichita",
  ],
  authors: [{ name: "Wichita Maid Service® | Clean Maid USA LLC" }],
  creator: "Wichita Maid Service® | Clean Maid USA LLC",
  publisher: "Wichita Maid Service® | Clean Maid USA LLC",
  alternates: { canonical: "/" },
  icons: { icon: "/logo.svg" },
  openGraph: {
    type: "website",
    locale: "en_US",
    url: SITE_URL,
    siteName: "Wichita Maid Service® | Clean Maid USA LLC",
    title:
      "Wichita Maid Service® | Clean Maid USA LLC — Professional Cleaning in Wichita, KS",
    description:
      "Professional Cleaning. Trusted Locally. Serving Wichita, KS since 2008. Insured, background-checked, family-owned.",
    images: [
      {
        url: "/images/hero-cleaning.jpg",
        width: 1344,
        height: 768,
        alt: "Professionally cleaned Wichita home interior",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    images: ["/images/hero-cleaning.jpg"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, "max-image-preview": "large" },
  },
  category: "Cleaning Services",
};

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "@id": `${SITE_URL}/#business`,
  name: "Wichita Maid Service® | Clean Maid USA LLC",
  legalName: "Clean Maid USA LLC",
  description:
    "Professional residential and commercial cleaning company serving Wichita, Kansas and surrounding areas since 2008. Insured, background-checked, family-owned.",
  url: SITE_URL,
  telephone: "+1-316-477-0101",
  foundingDate: "2008",
  priceRange: "$$",
  image: `${SITE_URL}/images/hero-cleaning.jpg`,
  logo: `${SITE_URL}/logo.svg`,
  address: {
    "@type": "PostalAddress",
    streetAddress: "1020 East English Street, Suite A1",
    addressLocality: "Wichita",
    addressRegion: "KS",
    postalCode: "67211",
    addressCountry: "US",
  },
  geo: {
    "@type": "GeoCoordinates",
    latitude: 37.6776,
    longitude: -97.3099,
  },
  email: "CleanMaidUS@gmail.com",
  areaServed: [
    "Wichita",
    "Maize",
    "Andover",
    "Bel Aire",
    "Haysville",
    "Park City",
    "Derby",
    "Eastborough",
    "Colwich",
    "Goddard",
    "Valley Center",
    "Sedgwick",
    "Rose Hill",
  ],
  knowsAbout: [
    "Residential Cleaning",
    "Commercial Cleaning",
    "Move-In / Move-Out Cleaning",
    "Post-Construction Cleaning",
    "Deep Cleaning",
    "Recurring Cleaning",
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${inter.variable} ${jakarta.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
      </body>
    </html>
  );
}
