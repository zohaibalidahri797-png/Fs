import Link from "next/link";
import { ArrowLeft, Phone, Home, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Container } from "@/components/site/section-primitives";
import { Header } from "@/components/site/header";
import { Footer } from "@/components/site/footer";
import { MobileCtaBar } from "@/components/site/mobile-cta-bar";

export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <Header />
      <main className="relative flex flex-1 items-center overflow-hidden bg-brand-navy pt-[68px] lg:pt-[76px]">
        <div className="pointer-events-none absolute -left-24 top-0 size-[420px] rounded-full bg-brand-teal/15 blur-[130px]" />
        <div className="pointer-events-none absolute -right-20 bottom-0 size-[360px] rounded-full bg-brand-aqua/10 blur-[130px]" />
        <div className="pointer-events-none absolute inset-0 bg-grid-light opacity-[0.06]" />
        <Container className="relative py-20 text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-3.5 py-1.5 text-xs font-semibold uppercase tracking-[0.2em] text-white/85 backdrop-blur">
            <Sparkles className="size-3.5 text-brand-aqua" />
            Page not found
          </span>
          <h1 className="mt-6 font-display text-[5rem] font-extrabold leading-none tracking-tight text-white sm:text-[7rem]">
            4<span className="text-gradient-brand">0</span>4
          </h1>
          <p className="mx-auto mt-4 max-w-md text-base leading-relaxed text-white/70">
            We couldn&apos;t find the page you were looking for. It may have
            been moved or no longer exists. Let&apos;s get you back to a cleaner
            space.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Button asChild size="lg" className="gap-2 bg-brand-teal text-white shadow-teal hover:bg-brand-teal/90">
              <Link href="/">
                <Home className="size-4" />
                Back to home
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="gap-2 border-white/25 bg-white/5 text-white backdrop-blur hover:bg-white/10 hover:text-white"
            >
              <a href="tel:3164770101">
                <Phone className="size-4" />
                Call (316) 477-0101
              </a>
            </Button>
          </div>
          <Link
            href="/"
            className="mt-6 inline-flex items-center gap-1.5 text-sm font-medium text-brand-aqua hover:underline"
          >
            <ArrowLeft className="size-4" />
            Return to Wichita Maid Service
          </Link>
        </Container>
      </main>
      <Footer />
      <MobileCtaBar />
    </div>
  );
}
