import { Header } from "@/components/site/header";
import { Hero } from "@/components/site/hero";
import { TrustBar } from "@/components/site/trust-bar";
import { SpecialOffer } from "@/components/site/special-offer";
import { Services } from "@/components/site/services";
import { WhyChooseUs } from "@/components/site/why-choose-us";
import { Audiences } from "@/components/site/audiences";
import { BeforeAfter } from "@/components/site/before-after";
import { HowItWorks } from "@/components/site/how-it-works";
import { About } from "@/components/site/about";
import { ServiceArea } from "@/components/site/service-area";
import { Reviews } from "@/components/site/reviews";
import { Commitment } from "@/components/site/commitment";
import { Faq } from "@/components/site/faq";
import { FinalCta } from "@/components/site/final-cta";
import { QuoteForm } from "@/components/site/quote-form";
import { Footer } from "@/components/site/footer";
import { MobileCtaBar } from "@/components/site/mobile-cta-bar";

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <Header />
      <main className="flex-1">
        <Hero />
        <TrustBar />
        <SpecialOffer />
        <Services />
        <WhyChooseUs />
        <Audiences />
        <BeforeAfter />
        <HowItWorks />
        <About />
        <ServiceArea />
        <Reviews />
        <Commitment />
        <Faq />
        <FinalCta />
        <QuoteForm />
      </main>
      <Footer />
      <MobileCtaBar />
    </div>
  );
}
