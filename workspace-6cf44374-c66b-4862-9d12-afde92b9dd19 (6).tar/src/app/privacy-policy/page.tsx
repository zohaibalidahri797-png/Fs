import type { Metadata } from "next";
import { PageLayout, PageCta } from "@/components/site/page-shell";
import { LegalContent } from "@/components/site/legal";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description:
    "Privacy policy for Wichita Maid Service® | Clean Maid USA LLC — how we handle information you provide via our quote and contact forms. We do not sell your personal information.",
  alternates: { canonical: "/privacy-policy" },
};

export default function PrivacyPolicyPage() {
  return (
    <PageLayout
      eyebrow="Legal"
      title="Privacy Policy"
      intro="Your privacy matters to us. This policy explains what information we collect and how we use it."
    >
      <LegalContent
        items={[
          {
            h: "Information we collect",
            p: [
              "We collect information you voluntarily provide through our quote and contact forms — such as your name, phone number, email, service and property details, scheduling preferences, and any message you include. We may also receive basic communication details when you call or email us.",
            ],
          },
          {
            h: "How we use your information",
            p: [
              "We use the information you provide to respond to quote requests, prepare estimates, schedule and perform cleaning services, communicate with you about service, and improve our website and services.",
            ],
          },
          {
            h: "Sharing your information",
            p: [
              "We do not sell your personal information. We may share information with service providers who help us operate our business (for example, communications or scheduling tools) under appropriate agreements, or when required by law.",
            ],
          },
          {
            h: "Cookies and analytics",
            p: [
              "Our website may use standard analytics or similar technologies to understand how the site is used. You can control cookies through your browser settings.",
            ],
          },
          {
            h: "Data retention",
            p: [
              "We keep personal information only as long as needed for the purposes described in this policy or as required by law.",
            ],
          },
          {
            h: "Your choices",
            p: [
              "You may contact us to ask about the information we hold, request correction, or opt out of any marketing communications.",
            ],
          },
          {
            h: "Security",
            p: [
              "We take reasonable measures to protect personal information. However, no method of transmission or storage is completely secure.",
            ],
          },
          {
            h: "Children's privacy",
            p: [
              "Our website is not directed to children, and we do not knowingly collect personal information from children.",
            ],
          },
          {
            h: "Changes to this policy",
            p: [
              "We may update this privacy policy from time to time. The \"last updated\" date below reflects the most recent revision.",
            ],
          },
          {
            h: "Contact us",
            p: [
              "If you have questions about this policy, contact us at CleanMaidUS@gmail.com or (316) 477-0101. Mailing address: 1020 East English Street, Suite A1, Wichita, KS 67211.",
            ],
          },
        ]}
      />
      <p className="pb-10 text-center text-xs text-muted-foreground">
        Last updated: {new Date().getFullYear()}
      </p>
      <PageCta />
    </PageLayout>
  );
}
