import type { Metadata } from "next";
import { PageLayout, PageCta } from "@/components/site/page-shell";
import { Reviews } from "@/components/site/reviews";

export const metadata: Metadata = {
  title: "Customer Reviews & Feedback",
  description:
    "See real customer feedback for Wichita Maid Service® | Clean Maid USA LLC. Read verified reviews on Google — professional, insured, background-checked cleaning in Wichita, KS since 2008.",
  alternates: { canonical: "/reviews" },
  openGraph: {
    title: "Customer Reviews | Wichita Maid Service®",
    description:
      "Real customer feedback for a trusted Wichita cleaning company. Read verified reviews on Google.",
  },
};

export default function ReviewsPage() {
  return (
    <PageLayout
      eyebrow="Reviews"
      title={
        <>
          Trusted by Wichita{" "}
          <span className="text-gradient-brand">home & business owners</span>
        </>
      }
      intro="See real customer feedback and learn more about the Clean Maid USA experience — verified reviews, directly on Google. Real feedback. No fabricated testimonials."
    >
      <Reviews showHeading={false} />
      <PageCta
        title="Become a customer we're proud of"
        copy="Join the Wichita homes and businesses who trust us with their cleaning. Get a free, personalized quote."
      />
    </PageLayout>
  );
}
