import type { Metadata } from "next";
import { PageLayout, PageCta } from "@/components/site/page-shell";
import { Services } from "@/components/site/services";

export const metadata: Metadata = {
  title: "Cleaning Services in Wichita, KS",
  description:
    "Professional cleaning services in Wichita, Kansas — residential, office & commercial, move-in/move-out, post-construction, deep, recurring, and customized cleaning. Insured, background-checked, family-owned since 2008. Get a free quote.",
  alternates: { canonical: "/services" },
  openGraph: {
    title: "Cleaning Services in Wichita, KS | Wichita Maid Service®",
    description:
      "Residential, commercial, move-in/move-out, post-construction, deep & recurring cleaning in Wichita, KS. Insured & background-checked. Free quotes.",
  },
};

export default function ServicesPage() {
  return (
    <PageLayout
      eyebrow="Our Services"
      title={
        <>
          Professional cleaning services{" "}
          <span className="text-gradient-brand">in Wichita, KS</span>
        </>
      }
      intro="From everyday home upkeep to specialized post-construction and commercial work — every service is delivered with the same attention to detail and personal care."
    >
      <Services showHeading={false} />
      <PageCta
        title="Not sure which service fits?"
        copy="Tell us about your space and priorities. We'll recommend the right approach and give you a free, no-obligation quote."
      />
    </PageLayout>
  );
}
