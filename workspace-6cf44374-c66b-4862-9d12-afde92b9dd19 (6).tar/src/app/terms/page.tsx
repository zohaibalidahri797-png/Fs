import type { Metadata } from "next";
import { PageLayout, PageCta } from "@/components/site/page-shell";
import { LegalContent } from "@/components/site/legal";

export const metadata: Metadata = {
  title: "Terms of Service",
  description:
    "Terms of service for the Wichita Maid Service® | Clean Maid USA LLC website — use of the site, cleaning services and quotes, intellectual property, and limitation of liability.",
  alternates: { canonical: "/terms" },
};

export default function TermsPage() {
  return (
    <PageLayout
      eyebrow="Legal"
      title="Terms of Service"
      intro="These terms govern your use of our website. Please read them carefully."
    >
      <LegalContent
        items={[
          {
            h: "Use of this website",
            p: [
              "You may use this website for lawful purposes only. You agree not to misuse the site, submit false information through our forms, or attempt to disrupt its operation.",
            ],
          },
          {
            h: "Cleaning services and quotes",
            p: [
              "Descriptions of cleaning services on this website are general. Actual cleaning services are provided under a separate agreement or confirmed quote. A quote is an estimate based on the information you provide; final scope and pricing are confirmed before service begins, and may be adjusted if actual conditions differ from what was described.",
            ],
          },
          {
            h: "No guarantees or warranties",
            p: [
              "We strive to deliver professional, quality cleaning. However, we do not guarantee specific outcomes beyond reasonable professional standards and do not make warranties beyond those required by applicable law.",
            ],
          },
          {
            h: "Intellectual property",
            p: [
              "Content on this website — including text, images, and the Wichita Maid Service® name and logo — is owned by Clean Maid USA LLC. You may not copy, reproduce, or reuse site content without our written permission.",
            ],
          },
          {
            h: "Third-party links",
            p: [
              "This website may link to third-party sites and services (for example, Google Maps and Google Reviews). We are not responsible for the content, accuracy, or practices of those third-party sites.",
            ],
          },
          {
            h: "Limitation of liability",
            p: [
              "To the extent permitted by law, Clean Maid USA LLC is not liable for any indirect, incidental, or consequential damages arising from your use of this website. Information on the site is provided for general purposes and is not professional advice.",
            ],
          },
          {
            h: "Changes to these terms",
            p: [
              "We may update these terms from time to time. Continued use of the website after changes are posted constitutes acceptance of the updated terms.",
            ],
          },
          {
            h: "Contact us",
            p: [
              "Questions about these terms? Contact us at CleanMaidUS@gmail.com or (316) 477-0101. Mailing address: 1020 East English Street, Suite A1, Wichita, KS 67211.",
            ],
          },
        ]}
      />
      <p className="pb-10 text-center text-xs text-muted-foreground">
        Last updated: {new Date().getFullYear()}
      </p>
      <PageCta />
    </PageLayout>
  );
}
