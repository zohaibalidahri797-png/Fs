"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { MapPin, CalendarCheck, Building2, HeartHandshake, ArrowRight, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Container, Section, Eyebrow } from "./section-primitives";
import { SmartImage } from "./smart-image";

const PILLARS = [
  { icon: MapPin, label: "Wichita-based" },
  { icon: CalendarCheck, label: "Established 2008" },
  { icon: Building2, label: "Residential & commercial" },
  { icon: HeartHandshake, label: "Customer-focused" },
];

export function About({ showHeading = true }: { showHeading?: boolean } = {}) {
  return (
    <Section id="about" className="bg-cream">
      <Container>
        <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-2 lg:gap-16">
          {/* Left — large editorial image */}
          <div className="relative">
            <div className="relative overflow-hidden rounded-3xl border border-border/70 shadow-premium-lg">
              <SmartImage
                src="/images/about-team.jpg"
                alt="Friendly professional cleaners from Wichita Maid Service — a local family-owned team"
                className="aspect-[4/3] w-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-brand-navy/45 via-transparent to-transparent" />

              {/* Established 2008 badge */}
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                className="absolute -bottom-5 -left-3 flex size-28 flex-col items-center justify-center rounded-full border border-border/70 bg-card text-center shadow-premium-lg sm:-left-6"
              >
                <Sparkles className="size-5 text-brand-teal" />
                <span className="mt-1 font-display text-2xl font-extrabold leading-none text-foreground">2008</span>
                <span className="mt-1 text-[0.58rem] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
                  Established
                </span>
              </motion.div>
            </div>
          </div>

          {/* Right — narrative */}
          <div>
            {showHeading && (
              <>
                <Eyebrow>About the Company</Eyebrow>
                <p className="mt-4 font-display text-sm font-bold uppercase tracking-[0.22em] text-brand-navy">
                  Local. Experienced. Professional.
                </p>
                <h2 className="mt-3 font-display text-3xl font-bold leading-[1.1] tracking-tight sm:text-4xl">
                  A Wichita family business{" "}
                  <span className="text-gradient-brand">built on relationships</span>
                </h2>
              </>
            )}
            <div className={`${showHeading ? "mt-5" : "mt-0"} space-y-4 text-base leading-relaxed text-foreground/75`}>
              <p>
                Wichita Maid Service<sup className="text-brand-teal">®</sup> | Clean
                Maid USA LLC was founded in Wichita, Kansas in 2008 as a local
                family operation with a simple belief: cleaning is about more
                than tidy spaces. It&apos;s about trust, consistency, and the
                people you rely on week after week.
              </p>
              <p>
                We&apos;ve grown through word-of-mouth and long-term
                relationships — not flashy advertising — delivering both
                residential and commercial cleaning with the same professional
                standard and customer-focused approach.
              </p>
              <p className="border-l-2 border-brand-teal/50 pl-4 text-foreground/85">
                Our goal isn&apos;t simply cleaning — it&apos;s building
                long-term relationships and finding real solutions for our
                customers&apos; cleaning needs.
              </p>
            </div>

            <div className="mt-7 grid grid-cols-2 gap-3 sm:grid-cols-4">
              {PILLARS.map((p) => (
                <div
                  key={p.label}
                  className="flex flex-col items-start gap-2 rounded-xl border border-border/60 bg-card p-3"
                >
                  <span className="flex size-8 items-center justify-center rounded-lg bg-brand-teal/10 text-brand-teal">
                    <p.icon className="size-4" strokeWidth={2.1} />
                  </span>
                  <span className="text-xs font-semibold leading-tight text-foreground/80">
                    {p.label}
                  </span>
                </div>
              ))}
            </div>

            <Button asChild className="mt-8 gap-2 bg-brand-navy shadow-premium hover:bg-brand-navy/90">
              <a href="/contact">
                Work with us
                <ArrowRight className="size-4" />
              </a>
            </Button>
          </div>
        </div>
      </Container>
    </Section>
  );
}
