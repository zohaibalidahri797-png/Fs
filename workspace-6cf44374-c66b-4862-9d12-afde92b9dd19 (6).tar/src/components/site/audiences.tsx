"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Home, Building2, ArrowRight, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Container, Section, SectionHeading, Eyebrow } from "./section-primitives";
import { SmartImage } from "./smart-image";

type Audience = {
  key: "homes" | "businesses";
  label: string;
  icon: React.ComponentType<{ className?: string; strokeWidth?: number }>;
  eyebrow: string;
  title: string;
  copy: string;
  image: string;
  alt: string;
  benefits: string[];
  cta: string;
};

const AUDIENCES: Record<"homes" | "businesses", Audience> = {
  homes: {
    key: "homes",
    label: "For Homes",
    icon: Home,
    eyebrow: "Residential cleaning",
    title: "Clean, healthy homes you can relax in",
    copy: "From busy households to detailed seasonal refreshes, we keep your home comfortable and cared for — exactly the way you like it.",
    image: "/images/residential-home.jpg",
    alt: "Spotless, sunlit Wichita living room after a professional residential cleaning",
    benefits: [
      "Tailored cleaning routines for your home",
      "Recurring weekly, bi-weekly & monthly plans",
      "Family-friendly products & careful approach",
      "Detail-oriented, every visit",
      "Trustworthy, local Wichita team",
    ],
    cta: "Get a residential quote",
  },
  businesses: {
    key: "businesses",
    label: "For Businesses",
    icon: Building2,
    eyebrow: "Commercial & office cleaning",
    title: "Professional spaces that reflect your standards",
    copy: "Consistent, professional cleaning that keeps your workplace healthy, presentable, and welcoming — for your team and your clients.",
    image: "/images/commercial-office.jpg",
    alt: "Pristine, modern Wichita office space after professional commercial cleaning",
    benefits: [
      "Consistent, professional appearance",
      "Healthy, disinfected work environment",
      "After-hours & flexible scheduling",
      "Restrooms, breakrooms & high-touch surfaces",
      "Single, reliable point of contact",
    ],
    cta: "Get a commercial quote",
  },
};

export function Audiences() {
  const [active, setActive] = React.useState<"homes" | "businesses">("homes");
  const data = AUDIENCES[active];

  return (
    <Section id="audiences" className="bg-background">
      <Container>
        <SectionHeading
          eyebrow="For Homes & Businesses"
          title={
            <>
              One trusted team for{" "}
              <span className="text-gradient-brand">homes and offices</span>
            </>
          }
          subtitle="Whether you're a homeowner who wants weekends back, or a business that needs a consistently professional space — we tailor our approach to fit."
        />

        {/* Segmented toggle */}
        <div className="mt-8 flex justify-center">
          <div className="inline-flex items-center rounded-full border border-border/70 bg-muted/60 p-1">
            {(Object.keys(AUDIENCES) as Array<keyof typeof AUDIENCES>).map((k) => {
              const a = AUDIENCES[k];
              const isActive = active === k;
              return (
                <button
                  key={k}
                  type="button"
                  onClick={() => setActive(k)}
                  className={
                    "relative inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold transition-colors " +
                    (isActive
                      ? "text-white"
                      : "text-foreground/70 hover:text-foreground")
                  }
                >
                  {isActive && (
                    <motion.span
                      layoutId="audience-pill"
                      className="absolute inset-0 -z-10 rounded-full bg-brand-teal shadow-teal"
                      transition={{ type: "spring", stiffness: 380, damping: 32 }}
                    />
                  )}
                  <a.icon className="size-4" strokeWidth={2.2} />
                  {a.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Content + image swap */}
        <div className="mt-12 grid grid-cols-1 items-center gap-10 lg:grid-cols-2">
          {/* Image */}
          <div className="relative">
            <AnimatePresence mode="wait">
              <motion.div
                key={data.key + "-img"}
                initial={{ opacity: 0, scale: 1.02 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.99 }}
                transition={{ duration: 0.4, ease: "easeOut" }}
                className="relative overflow-hidden rounded-2xl border border-border/70 shadow-premium-lg"
              >
                <SmartImage
                  src={data.image}
                  alt={data.alt}
                  className="aspect-[4/3] w-full object-cover"
                />
                <span className="absolute left-4 top-4 inline-flex items-center gap-1.5 rounded-full border border-border/70 bg-background/90 px-3 py-1.5 text-xs font-semibold text-brand-teal backdrop-blur">
                  <data.icon className="size-3.5" />
                  {data.eyebrow}
                </span>
              </motion.div>
            </AnimatePresence>

            {/* Decorative accent */}
            <div className="pointer-events-none absolute -bottom-5 -right-5 -z-10 size-32 rounded-full bg-brand-aqua/20 blur-2xl" />
          </div>

          {/* Content */}
          <AnimatePresence mode="wait">
            <motion.div
              key={data.key + "-content"}
              initial={{ opacity: 0, x: 16 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -16 }}
              transition={{ duration: 0.4, ease: "easeOut" }}
            >
              <Eyebrow tone="aqua">{data.eyebrow}</Eyebrow>
              <h3 className="mt-4 font-display text-3xl font-bold leading-tight tracking-tight">
                {data.title}
              </h3>
              <p className="mt-3 max-w-lg text-base leading-relaxed text-muted-foreground">
                {data.copy}
              </p>

              <ul className="mt-6 space-y-3">
                {data.benefits.map((b) => (
                  <li key={b} className="flex items-start gap-3">
                    <span className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-brand-teal/12 text-brand-teal">
                      <Check className="size-3.5" strokeWidth={3} />
                    </span>
                    <span className="text-sm leading-relaxed text-foreground/80">
                      {b}
                    </span>
                  </li>
                ))}
              </ul>

              <Button asChild className="mt-8 gap-2 bg-brand-navy shadow-premium hover:bg-brand-navy/90">
                <a href="/contact">
                  {data.cta}
                  <ArrowRight className="size-4" />
                </a>
              </Button>
            </motion.div>
          </AnimatePresence>
        </div>
      </Container>
    </Section>
  );
}
