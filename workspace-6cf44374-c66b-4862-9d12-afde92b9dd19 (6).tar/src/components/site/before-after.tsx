"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Sparkles, MoveHorizontal, Camera } from "lucide-react";
import { Container, Section, SectionHeading, Eyebrow } from "./section-primitives";
import { SmartImage } from "./smart-image";

export function BeforeAfter() {
  const containerRef = React.useRef<HTMLDivElement>(null);
  const [pos, setPos] = React.useState(52);
  const [dragging, setDragging] = React.useState(false);

  const setFromClientX = React.useCallback((clientX: number) => {
    const el = containerRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const pct = ((clientX - rect.left) / rect.width) * 100;
    setPos(Math.min(100, Math.max(0, pct)));
  }, []);

  React.useEffect(() => {
    if (!dragging) return;
    const onMove = (e: PointerEvent) => setFromClientX(e.clientX);
    const onUp = () => setDragging(false);
    window.addEventListener("pointermove", onMove, { passive: true });
    window.addEventListener("pointerup", onUp);
    window.addEventListener("pointercancel", onUp);
    return () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("pointercancel", onUp);
    };
  }, [dragging, setFromClientX]);

  return (
    <Section className="bg-brand-mist">
      <Container>
        <div className="flex flex-col items-center gap-4 text-center">
          <Eyebrow tone="aqua">The Difference</Eyebrow>
          <h2 className="mx-auto max-w-3xl font-display text-3xl font-bold leading-[1.08] tracking-tight sm:text-4xl lg:text-[2.6rem]">
            This is the result{" "}
            <span className="text-gradient-brand">we create</span>
          </h2>
          <p className="mx-auto max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
            Drag the handle to reveal the transformation — the same room, before
            and after our team&apos;s detailed cleaning.
          </p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.55, ease: "easeOut" }}
          className="relative mx-auto mt-10 max-w-4xl"
        >
          <div
            ref={containerRef}
            onPointerDown={(e) => {
              setDragging(true);
              setFromClientX(e.clientX);
            }}
            className="relative aspect-[16/10] w-full cursor-ew-resize select-none overflow-hidden rounded-2xl border border-border/70 bg-card shadow-premium-lg"
          >
            <SmartImage
              src="/images/before-messy.jpg"
              alt="Living room before professional cleaning"
              className="absolute inset-0 size-full object-cover"
              draggable={false}
            />
            <div
              className="absolute inset-0 size-full overflow-hidden"
              style={{ clipPath: `inset(0 0 0 ${pos}%)` }}
            >
              <SmartImage
                src="/images/after-clean.jpg"
                alt="The same living room after a professional, detailed cleaning"
                className="absolute inset-0 size-full object-cover"
                draggable={false}
              />
            </div>

            {/* Labels */}
            <span className="pointer-events-none absolute left-4 top-4 rounded-full border border-border/60 bg-background/85 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground backdrop-blur">
              Before
            </span>
            <span className="pointer-events-none absolute right-4 top-4 inline-flex items-center gap-1.5 rounded-full border border-brand-teal/30 bg-brand-teal/12 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-brand-teal backdrop-blur">
              <Sparkles className="size-3.5" />
              After
            </span>

            {/* Glow under handle */}
            <div
              className="pointer-events-none absolute top-0 bottom-0 z-10"
              style={{ left: `${pos}%`, transform: "translateX(-50%)" }}
            >
              <div className="absolute top-1/2 left-1/2 size-16 -translate-x-1/2 -translate-y-1/2 rounded-full bg-brand-teal/25 blur-xl" />
              <div className="absolute top-0 bottom-0 left-1/2 w-0.5 -translate-x-1/2 bg-background/90 ring-1 ring-brand-teal/30" />
              <div className="absolute top-1/2 left-1/2 flex size-12 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border border-brand-teal/40 bg-background text-brand-teal shadow-premium-lg">
                <MoveHorizontal className="size-5" strokeWidth={2.4} />
              </div>
            </div>

            {/* Drag hint */}
            <div className="pointer-events-none absolute bottom-4 left-1/2 flex -translate-x-1/2 items-center gap-1.5 rounded-full border border-border/60 bg-background/85 px-3 py-1.5 text-xs font-medium text-muted-foreground backdrop-blur">
              <Sparkles className="size-3.5 text-brand-aqua" />
              Drag to compare
            </div>
          </div>

          {/* Honest illustrative note */}
          <div className="mt-4 flex items-center justify-center gap-2 text-center text-xs text-muted-foreground">
            <Camera className="size-3.5 text-brand-teal" />
            <span>
              Illustrative example, shown to demonstrate the level of clean our
              team delivers — not a specific client project.
            </span>
          </div>
        </motion.div>
      </Container>
    </Section>
  );
}
