import * as React from "react";
import { Sparkles, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Container, Eyebrow } from "./section-primitives";
import { SmartImage } from "./smart-image";

export function Commitment() {
  return (
    <section className="relative isolate overflow-hidden">
      {/* Full-bleed strong image */}
      <SmartImage
        src="/images/after-clean.jpg"
        alt="A spotless, professionally cleaned living space — more time for what matters"
        className="absolute inset-0 -z-10 size-full object-cover"
      />
      <div className="absolute inset-0 -z-10 bg-gradient-to-r from-brand-navy/92 via-brand-navy/75 to-brand-navy/40" />
      <div className="absolute inset-0 -z-10 bg-gradient-to-t from-brand-navy/80 via-transparent to-brand-navy/30" />

      <Container className="py-24 sm:py-28 lg:py-32">
        <div className="max-w-2xl">
          <Eyebrow tone="aqua">Our Commitment</Eyebrow>
          <h2 className="mt-4 font-display text-3xl font-bold leading-[1.08] tracking-tight text-white sm:text-4xl lg:text-5xl">
            A Cleaner Space.{" "}
            <span className="text-gradient-brand">More Time for What Matters.</span>
          </h2>
          <p className="mt-5 max-w-xl text-base leading-relaxed text-white/80 sm:text-lg">
            We don&apos;t just clean — we give you back your time, your comfort,
            and your peace of mind. A healthier home, a more professional office,
            and one less thing on your plate.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Button asChild size="lg" className="gap-2 bg-brand-teal text-white shadow-teal hover:bg-brand-teal/90">
              <a href="/contact">
                <Sparkles className="size-4" />
                Get a Free Quote
              </a>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="gap-2 border-white/25 bg-white/5 text-white backdrop-blur hover:bg-white/10 hover:text-white"
            >
              <a href="/services">
                Explore our services
                <ArrowRight className="size-4" />
              </a>
            </Button>
          </div>
        </div>
      </Container>
    </section>
  );
}
