export type FaqItem = { q: string; a: string };

export const FAQS: FaqItem[] = [
  {
    q: "What areas around Wichita do you serve?",
    a: "We're based in Wichita and regularly clean across the metro and surrounding communities, including Andover, Derby, Maize, Goddard, Park City, Haysville, Bel Aire, and nearby areas. If you're unsure whether we cover your location, just ask — we likely do.",
  },
  {
    q: "Are your cleaners background-checked and insured?",
    a: "Yes. Our team members are background-checked, and our service is insured. We want you to feel completely comfortable with whoever is in your home or office.",
  },
  {
    q: "Do I need to be home during the cleaning?",
    a: "No, you don't have to be. Many of our recurring customers provide access and go about their day. We'll arrange the access method that works for you and your schedule.",
  },
  {
    q: "What cleaning supplies and equipment do you use?",
    a: "We use professional-grade supplies and equipment for a thorough, lasting clean. If you have preferences or sensitivities, tell us — we're happy to accommodate your home or business.",
  },
  {
    q: "How do I schedule a recurring cleaning plan?",
    a: "Request a free quote, and we'll walk through your needs together. We'll set up a weekly, bi-weekly, or monthly plan that fits your routine, with the flexibility to pause or adjust as life changes.",
  },
  {
    q: "What's the difference between a deep clean and a regular clean?",
    a: "A regular clean keeps up with everyday surfaces and high-traffic areas. A deep clean goes further — baseboards, trim, detailed tile and grout, and the harder-to-reach spots that need extra attention. We'll recommend the right approach for your space.",
  },
  {
    q: "Do you offer same-day service?",
    a: "When the schedule allows, we offer same-day service for time-sensitive needs. Availability depends on the day and demand, so call (316) 477-0101 and we'll do our best to fit you in.",
  },
  {
    q: "How does pricing work?",
    a: "Pricing is based on your space, the type of cleaning, and your priorities. We provide a free, personalized, no-obligation quote — never a vague estimate — so you know exactly what you're paying for.",
  },
  {
    q: "What is your cancellation or rescheduling policy?",
    a: "Life happens. We just ask for reasonable notice so we can adjust the schedule. Reach out as early as you can and we'll work with you to reschedule without hassle.",
  },
  {
    q: "Do you clean offices and commercial spaces, too?",
    a: "Yes. We provide professional commercial and office cleaning — workstations, restrooms, breakrooms, and high-touch surface disinfecting — with after-hours and flexible scheduling options.",
  },
];
