"use client";

import * as React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Phone, HelpCircle, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Container, Section, SectionHeading } from "./section-primitives";
import { FAQS } from "./faq-data";

export function Faq({ showHeading = true }: { showHeading?: boolean } = {}) {
  return (
    <Section id="faq" className="bg-cream">
      <Container>
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-12 lg:gap-14">
          {/* Left — heading + contact card */}
          <div className="lg:col-span-5">
            {showHeading && (
              <SectionHeading
                align="left"
                eyebrow="FAQ"
                title={
                  <>
                    Answers to{" "}
                    <span className="text-gradient-brand">common questions</span>
                  </>
                }
                subtitle="Everything you need to know about working with us. Can't find your answer? We're a quick call away."
              />
            )}
            <div className={`${showHeading ? "mt-8" : "mt-0"} rounded-2xl border border-border/70 bg-card p-6 shadow-premium`}>
              <div className="flex items-center gap-3">
                <span className="flex size-11 items-center justify-center rounded-xl bg-brand-teal/10 text-brand-teal">
                  <HelpCircle className="size-5" strokeWidth={2.1} />
                </span>
                <div>
                  <div className="font-display text-base font-bold leading-tight text-foreground">
                    Still have questions?
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Talk to a real person on our Wichita team.
                  </div>
                </div>
              </div>
              <Button asChild className="mt-5 w-full gap-2 bg-brand-navy shadow-premium hover:bg-brand-navy/90">
                <a href="tel:3164770101">
                  <Phone className="size-4" />
                  (316) 477-0101
                </a>
              </Button>
              <a
                href="/contact"
                className="mt-3 flex items-center justify-center gap-1.5 text-sm font-semibold text-brand-teal hover:underline"
              >
                Or request a free quote
                <ArrowRight className="size-4" />
              </a>
            </div>
          </div>

          {/* Right — accordion */}
          <div className="lg:col-span-7">
            <Accordion type="single" collapsible className="flex flex-col gap-3">
              {FAQS.map((f, i) => (
                <AccordionItem
                  key={f.q}
                  value={`item-${i}`}
                  className="overflow-hidden rounded-xl border border-border/70 bg-card px-5 shadow-premium data-[state=open]:border-brand-teal/40"
                >
                  <AccordionTrigger className="text-left font-display text-base font-bold tracking-tight text-foreground hover:no-underline">
                    {f.q}
                  </AccordionTrigger>
                  <AccordionContent className="text-sm leading-relaxed text-muted-foreground">
                    {f.a}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </Container>
    </Section>
  );
}
