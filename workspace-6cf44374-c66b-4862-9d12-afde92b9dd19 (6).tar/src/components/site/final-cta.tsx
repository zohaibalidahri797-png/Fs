import * as React from "react";
import { CalendarCheck, Phone, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Container, Section } from "./section-primitives";

export function FinalCta() {
  return (
    <Section className="relative overflow-hidden bg-brand-navy py-20 sm:py-24">
      <div className="pointer-events-none absolute -left-24 top-0 size-[420px] rounded-full bg-brand-teal/20 blur-[130px]" />
      <div className="pointer-events-none absolute -right-24 bottom-0 size-[360px] rounded-full bg-brand-aqua/12 blur-[130px]" />
      <div className="pointer-events-none absolute inset-0 bg-grid-light opacity-[0.06]" />
      <Container className="relative text-center">
        <span className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-3.5 py-1.5 text-xs font-semibold uppercase tracking-[0.2em] text-white/85 backdrop-blur">
          <Sparkles className="size-3.5 text-brand-aqua" />
          Ready when you are
        </span>
        <h2 className="mx-auto mt-5 max-w-3xl font-display text-3xl font-bold leading-[1.08] tracking-tight text-white sm:text-4xl lg:text-5xl">
          Ready for a cleaner space,{" "}
          <span className="text-gradient-brand">trusted locally?</span>
        </h2>
        <p className="mx-auto mt-4 max-w-xl text-base leading-relaxed text-white/75 sm:text-lg">
          Get a free, personalized quote from our Wichita team — for your home
          or your business. Insured, background-checked, and built on
          relationships since 2008.
        </p>
        <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <Button asChild size="lg" className="gap-2 bg-brand-teal text-white shadow-teal hover:bg-brand-teal/90">
            <a href="/contact">
              <CalendarCheck className="size-4" />
              Get a Free Quote
            </a>
          </Button>
          <Button
            asChild
            size="lg"
            variant="outline"
            className="gap-2 border-white/25 bg-white/5 text-white backdrop-blur hover:bg-white/10 hover:text-white"
          >
            <a href="tel:3164770101">
              <Phone className="size-4" />
              Call (316) 477-0101
            </a>
          </Button>
        </div>
      </Container>
    </Section>
  );
}
