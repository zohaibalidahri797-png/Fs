import * as React from "react";
import { Phone, Globe, MapPin, Mail, ArrowUp } from "lucide-react";
import { Logo } from "./logo";
import { Container } from "./section-primitives";

const SERVICES_LINKS = [
  "Residential Cleaning",
  "Office & Commercial Cleaning",
  "Move-In / Move-Out Cleaning",
  "Post-Construction Cleaning",
  "Deep Cleaning",
  "Recurring Cleaning",
  "Customized Cleaning Services",
];

const AREA_LINKS = [
  "Wichita",
  "Andover",
  "Derby",
  "Maize",
  "Goddard",
  "Park City",
  "Haysville",
  "Bel Aire",
];

export function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="mt-auto border-t border-white/10 bg-brand-navy text-white">
      <Container className="py-14 pb-28 lg:pb-14">
        <div className="grid grid-cols-2 gap-10 md:grid-cols-4 lg:grid-cols-5">
          {/* Brand */}
          <div className="col-span-2 lg:col-span-2">
            <Logo variant="onDark" />
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-white/65">
              A local, family-owned cleaning company serving Wichita, Kansas and
              surrounding areas since 2008. Professional cleaning you can trust —
              for homes and businesses.
            </p>
            <div className="mt-5 flex flex-col gap-2 text-sm">
              <a href="tel:3164770101" className="inline-flex items-center gap-2 text-white/80 transition-colors hover:text-brand-aqua">
                <Phone className="size-4 text-brand-aqua" />
                (316) 477-0101
              </a>
              <a
                href="mailto:CleanMaidUS@gmail.com"
                className="inline-flex items-center gap-2 text-white/80 transition-colors hover:text-brand-aqua"
              >
                <Mail className="size-4 text-brand-aqua" />
                CleanMaidUS@gmail.com
              </a>
              <a
                href="https://cleanmaidusa.com"
                className="inline-flex items-center gap-2 text-white/80 transition-colors hover:text-brand-aqua"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Globe className="size-4 text-brand-aqua" />
                cleanmaidusa.com
              </a>
              <span className="inline-flex items-start gap-2 text-white/80">
                <MapPin className="mt-0.5 size-4 shrink-0 text-brand-aqua" />
                1020 East English Street, Suite A1, Wichita, KS 67211
              </span>
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-[0.18em] text-white/55">
              Services
            </h3>
            <ul className="mt-4 space-y-2">
              {SERVICES_LINKS.map((s) => (
                <li key={s}>
                  <a href="/services" className="text-sm text-white/65 transition-colors hover:text-brand-aqua">
                    {s}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Service area */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-[0.18em] text-white/55">
              Service Area
            </h3>
            <ul className="mt-4 space-y-2">
              {AREA_LINKS.map((s) => (
                <li key={s}>
                  <a href="/#service-area" className="text-sm text-white/65 transition-colors hover:text-brand-aqua">
                    {s}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-[0.18em] text-white/55">
              Company
            </h3>
            <ul className="mt-4 space-y-2">
              <li><a href="/#why-us" className="text-sm text-white/65 hover:text-brand-aqua">Why choose us</a></li>
              <li><a href="/about" className="text-sm text-white/65 hover:text-brand-aqua">About</a></li>
              <li><a href="/reviews" className="text-sm text-white/65 hover:text-brand-aqua">Reviews</a></li>
              <li><a href="/faq" className="text-sm text-white/65 hover:text-brand-aqua">FAQ</a></li>
              <li><a href="/contact" className="text-sm text-white/65 hover:text-brand-aqua">Get a free quote</a></li>
            </ul>
            <a href="/" className="mt-5 inline-flex items-center gap-1.5 text-sm font-medium text-brand-aqua hover:underline">
              <ArrowUp className="size-4" />
              Back to home
            </a>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-3 border-t border-white/10 pt-6 text-center sm:flex-row sm:text-left">
          <p className="text-xs text-white/55">
            © 2008–{year} Wichita Maid Service<sup className="text-brand-aqua">®</sup> | Clean Maid USA LLC. All
            rights reserved.
          </p>
          <nav aria-label="Legal" className="flex flex-wrap items-center justify-center gap-x-4 gap-y-1 text-xs text-white/55">
            <a href="/privacy-policy" className="transition-colors hover:text-brand-aqua">Privacy Policy</a>
            <span className="text-white/20">·</span>
            <a href="/terms" className="transition-colors hover:text-brand-aqua">Terms</a>
            <span className="text-white/20">·</span>
            <a href="/disclaimer" className="transition-colors hover:text-brand-aqua">Disclaimer</a>
          </nav>
        </div>
      </Container>
    </footer>
  );
}
