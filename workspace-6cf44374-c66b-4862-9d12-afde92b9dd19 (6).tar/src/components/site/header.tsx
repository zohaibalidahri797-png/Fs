"use client";

import * as React from "react";
import { Menu, X, Phone, CalendarCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Logo } from "./logo";
import { Container } from "./section-primitives";

const NAV_LINKS = [
  { label: "Home", href: "/" },
  { label: "Services", href: "/services" },
  { label: "Why Choose Us", href: "/#why-us" },
  { label: "About", href: "/about" },
  { label: "Reviews", href: "/reviews" },
  { label: "FAQ", href: "/faq" },
  { label: "Contact", href: "/contact" },
];

export function Header() {
  const [scrolled, setScrolled] = React.useState(false);
  const [open, setOpen] = React.useState(false);

  React.useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  React.useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-300",
        scrolled
          ? "border-b border-border/70 bg-background/85 shadow-premium backdrop-blur-xl"
          : "border-b border-transparent bg-transparent",
      )}
    >
      <Container className="flex h-[68px] items-center justify-between gap-4 lg:h-[76px]">
        <a href="/" aria-label="Wichita Maid Service home" className="shrink-0">
          <Logo />
        </a>

        <nav className="hidden items-center gap-0.5 lg:flex" aria-label="Primary">
          {NAV_LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="rounded-full px-2.5 text-sm font-medium text-foreground/75 transition-colors hover:bg-brand-mist hover:text-foreground xl:px-3.5"
            >
              {l.label}
            </a>
          ))}
        </nav>

        <div className="hidden items-center gap-2 lg:flex">
          <span className="hidden xl:inline-flex">
            <Button asChild variant="ghost" size="sm" className="gap-2 text-foreground/80">
              <a href="tel:3164770101">
                <Phone className="size-4 text-brand-teal" />
                (316) 477-0101
              </a>
            </Button>
          </span>
          <Button asChild size="sm" className="gap-2 bg-brand-navy shadow-premium hover:bg-brand-navy/90">
            <a href="/contact">
              <CalendarCheck className="size-4" />
              Get a Free Quote
            </a>
          </Button>
        </div>

        {/* Mobile: phone icon + menu */}
        <div className="flex items-center gap-1.5 lg:hidden">
          <a
            href="tel:3164770101"
            aria-label="Call (316) 477-0101"
            className="inline-flex size-10 items-center justify-center rounded-lg border border-border/70 bg-background/70 text-brand-teal"
          >
            <Phone className="size-5" />
          </a>
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            className="inline-flex size-10 items-center justify-center rounded-lg border border-border/70 bg-background/70 text-foreground"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
      </Container>

      {/* Mobile drawer */}
      <div
        className={cn(
          "lg:hidden overflow-hidden border-t border-border/60 bg-background/98 backdrop-blur-xl transition-[max-height,opacity] duration-300",
          open ? "max-h-[520px] opacity-100" : "max-h-0 opacity-0",
        )}
      >
        <Container className="flex flex-col gap-1 py-4">
          {NAV_LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="rounded-lg px-3 py-2.5 text-base font-medium text-foreground/80 transition-colors hover:bg-brand-mist hover:text-foreground"
            >
              {l.label}
            </a>
          ))}
          <div className="mt-2 flex flex-col gap-2 border-t border-border/60 pt-3">
            <Button asChild variant="outline" className="gap-2">
              <a href="tel:3164770101" onClick={() => setOpen(false)}>
                <Phone className="size-4 text-brand-teal" />
                (316) 477-0101
              </a>
            </Button>
            <Button asChild className="gap-2 bg-brand-navy shadow-premium hover:bg-brand-navy/90">
              <a href="/contact" onClick={() => setOpen(false)}>
                <CalendarCheck className="size-4" />
                Get a Free Quote
              </a>
            </Button>
          </div>
        </Container>
      </div>
    </header>
  );
}
