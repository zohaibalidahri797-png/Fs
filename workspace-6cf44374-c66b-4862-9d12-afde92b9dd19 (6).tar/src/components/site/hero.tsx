"use client";

import * as React from "react";
import {
  motion,
  useMotionValue,
  useSpring,
  useScroll,
  useTransform,
} from "framer-motion";
import {
  ArrowRight,
  Phone,
  ShieldCheck,
  BadgeCheck,
  Sparkles,
  CalendarCheck,
  Star,
  HeartHandshake,
  SprayCan,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Container } from "./section-primitives";

const TRUST = [
  { icon: Sparkles, label: "Est. 2008" },
  { icon: ShieldCheck, label: "Insured" },
  { icon: BadgeCheck, label: "Background-checked" },
  { icon: Star, label: "Family-owned" },
];

export function Hero() {
  const ref = React.useRef<HTMLDivElement>(null);

  // Mouse parallax
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const sx = useSpring(mx, { stiffness: 120, damping: 20, mass: 0.4 });
  const sy = useSpring(my, { stiffness: 120, damping: 20, mass: 0.4 });

  // Scroll parallax
  const { scrollY } = useScroll();
  const bgScrollY = useTransform(scrollY, [0, 600], [0, 40]);
  const bgScrollScale = useTransform(scrollY, [0, 600], [1.1, 1.16]);

  const bgX = useTransform(sx, [-0.5, 0.5], [-8, 8]);
  const bgY = useTransform(sy, [-0.5, 0.5], [-6, 6]);
  // Distinct depth layers — each moves at a different speed for real parallax
  const sealX = useTransform(sx, [-0.5, 0.5], [13, -13]);
  const sealY = useTransform(sy, [-0.5, 0.5], [10, -10]);
  const chip1X = useTransform(sx, [-0.5, 0.5], [20, -20]);
  const chip1Y = useTransform(sy, [-0.5, 0.5], [15, -15]);
  const chip2X = useTransform(sx, [-0.5, 0.5], [26, -26]);
  const chip2Y = useTransform(sy, [-0.5, 0.5], [19, -19]);
  const chip3X = useTransform(sx, [-0.5, 0.5], [11, -11]);
  const chip3Y = useTransform(sy, [-0.5, 0.5], [8, -8]);
  const sprayX = useTransform(sx, [-0.5, 0.5], [30, -30]);
  const sprayY = useTransform(sy, [-0.5, 0.5], [22, -22]);
  const sparkX = useTransform(sx, [-0.5, 0.5], [34, -34]);
  const sparkY = useTransform(sy, [-0.5, 0.5], [26, -26]);
  // 3D perspective tilt — gives the layered composition genuine spatial depth
  const tiltX = useTransform(sy, [-0.5, 0.5], [3.5, -3.5]);
  const tiltY = useTransform(sx, [-0.5, 0.5], [-4, 4]);
  // Scroll parallax — foreground cards drift up gently (opposite the bg) for depth
  const floatScrollY = useTransform(scrollY, [0, 700], [0, -34]);

  const [parallax, setParallax] = React.useState(false);
  React.useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    setParallax(true);
    const onMove = (e: MouseEvent) => {
      mx.set(e.clientX / window.innerWidth - 0.5);
      my.set(e.clientY / window.innerHeight - 0.5);
    };
    window.addEventListener("mousemove", onMove, { passive: true });
    return () => window.removeEventListener("mousemove", onMove);
  }, [mx, my]);

  return (
    <section
      id="top"
      ref={ref}
      className="relative isolate flex min-h-[92svh] flex-col overflow-hidden bg-brand-navy pt-[68px] lg:pt-[76px]"
      style={{ perspective: 1200 }}
    >
      {/* LAYER 1 — background atmosphere */}
      <div className="pointer-events-none absolute inset-0 -z-30">
        <div className="absolute inset-0 bg-gradient-to-br from-brand-navy via-[#13294f] to-[#0a1c38]" />
        <div className="absolute -left-24 top-10 size-[420px] rounded-full bg-brand-teal/20 blur-[120px]" />
        <div className="absolute right-0 top-1/3 size-[360px] rounded-full bg-brand-aqua/15 blur-[120px]" />
      </div>

      {/* LAYER 2 — large cleaning/home visual */}
      <motion.div
        className="absolute inset-0 -z-20"
        style={{
          y: parallax ? bgScrollY : 0,
          scale: parallax ? bgScrollScale : 1.1,
        }}
      >
        <motion.img
          src="/images/hero-cleaning.jpg"
          alt="Bright, spotless, professionally cleaned Wichita home interior"
          className="absolute inset-0 size-full object-cover"
          style={{
            x: parallax ? bgX : 0,
            y: parallax ? bgY : 0,
            scale: 1.08,
            willChange: "transform",
          }}
          fetchPriority="high"
        />
        {/* Readability overlays */}
        <div className="absolute inset-0 bg-gradient-to-r from-brand-navy/94 via-brand-navy/72 to-brand-navy/25" />
        <div className="absolute inset-0 bg-gradient-to-t from-brand-navy/85 via-transparent to-brand-navy/30" />
      </motion.div>

      {/* LAYER 3 & 4 & 5 — content + floating depth cards */}
      <Container className="relative z-10 flex flex-1 flex-col justify-center py-12 lg:py-20">
        <div
          className="grid grid-cols-1 items-center gap-10 lg:grid-cols-12"
          style={{ perspective: 1000 }}
        >
          {/* Text column */}
          <div className="lg:col-span-7">
            <motion.div
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-3.5 py-1.5 text-xs font-semibold uppercase tracking-[0.18em] text-white/85 backdrop-blur text-shadow-hero"
            >
              <span className="relative flex size-2">
                <span className="absolute inline-flex size-full animate-ping rounded-full bg-brand-aqua/60" />
                <span className="relative inline-flex size-2 rounded-full bg-brand-aqua" />
              </span>
              Wichita&apos;s trusted cleaning team since 2008
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.05 }}
              className="mt-4 font-display text-[2.05rem] font-extrabold leading-[1.05] tracking-tight text-white text-shadow-hero sm:text-5xl lg:text-6xl"
            >
              Professional Cleaning.
              <br />
              <span className="text-gradient-brand">Trusted Locally.</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.12 }}
              className="mt-4 max-w-xl text-[0.95rem] leading-relaxed text-white/80 text-shadow-hero sm:text-lg"
            >
              A local, family-owned cleaning company delivering spotless homes and
              professional offices across Wichita, Kansas. Insured,
              background-checked, and built on long-term relationships.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.19 }}
              className="mt-6 flex flex-col gap-2.5 sm:flex-row sm:gap-3"
            >
              <Button asChild size="lg" className="gap-2 bg-brand-teal text-white shadow-teal hover:bg-brand-teal/90">
                <a href="#quote">
                  <CalendarCheck className="size-4" />
                  Get a Free Quote
                </a>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="gap-2 border-white/25 bg-white/5 text-white backdrop-blur hover:bg-white/10 hover:text-white"
              >
                <a href="tel:3164770101">
                  <Phone className="size-4" />
                  Call Now
                </a>
              </Button>
            </motion.div>

            <motion.ul
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.26 }}
              className="mt-6 flex flex-wrap items-center gap-x-4 gap-y-2 text-shadow-hero"
            >
              {TRUST.map((b) => (
                <li
                  key={b.label}
                  className="flex items-center gap-2 text-sm font-medium text-white/75"
                >
                  <b.icon className="size-4 text-brand-aqua" strokeWidth={2.1} />
                  {b.label}
                </li>
              ))}
            </motion.ul>
          </div>
          <motion.div
            className="relative hidden h-full lg:col-span-5 lg:block"
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            style={{
              transformStyle: "preserve-3d",
              y: parallax ? floatScrollY : 0,
              rotateX: parallax ? tiltX : 0,
              rotateY: parallax ? tiltY : 0,
            }}
          >
            {/* LAYER 3 — "17+ Years Serving Wichita" seal (depth: mid1) */}
            <motion.div
              style={parallax ? { x: sealX, y: sealY, z: 40 } : undefined}
              className="absolute right-4 top-3 flex size-32 flex-col items-center justify-center rounded-full border border-white/15 bg-white/10 text-center text-white shadow-premium-lg backdrop-blur-xl"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.35 }}
            >
              <Sparkles className="size-5 text-brand-aqua" />
              <span className="mt-1 font-display text-2xl font-extrabold leading-none">2008</span>
              <span className="mt-1 text-[0.58rem] font-semibold uppercase tracking-[0.16em] text-white/65">
                Established
              </span>
              <span className="mt-0.5 text-[0.5rem] font-medium uppercase tracking-[0.14em] text-brand-aqua">
                17+ yrs in Wichita
              </span>
            </motion.div>

            {/* LAYER 4 — Insured trust chip (depth: mid2) */}
            <motion.div
              style={parallax ? { x: chip1X, y: chip1Y, z: 80 } : undefined}
              className="absolute right-6 top-[37%] w-44 rounded-2xl border border-white/15 bg-white/10 p-4 text-white shadow-premium-lg backdrop-blur-xl"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.45 }}
            >
              <span className="flex size-9 items-center justify-center rounded-lg bg-brand-teal/25 text-brand-aqua">
                <ShieldCheck className="size-5" strokeWidth={2.1} />
              </span>
              <p className="mt-2.5 font-display text-sm font-bold leading-tight">Insured Service</p>
              <p className="mt-0.5 text-xs leading-snug text-white/65">Fully insured on every visit.</p>
            </motion.div>

            {/* LAYER 4 — Background-checked chip (depth: fast1) */}
            <motion.div
              style={parallax ? { x: chip2X, y: chip2Y, z: 110 } : undefined}
              className="absolute right-4 top-[55%] w-44 rounded-2xl border border-white/15 bg-white/10 p-4 text-white shadow-premium-lg backdrop-blur-xl"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.55 }}
            >
              <span className="flex size-9 items-center justify-center rounded-lg bg-brand-teal/25 text-brand-aqua">
                <BadgeCheck className="size-5" strokeWidth={2.1} />
              </span>
              <p className="mt-2.5 font-display text-sm font-bold leading-tight">Background-Checked</p>
              <p className="mt-0.5 text-xs leading-snug text-white/65">Vetted, trusted team.</p>
            </motion.div>

            {/* LAYER 4 — Family-owned chip (depth: mid3) */}
            <motion.div
              style={parallax ? { x: chip3X, y: chip3Y, z: 60 } : undefined}
              className="absolute right-6 bottom-6 w-44 rounded-2xl border border-white/15 bg-white/10 p-4 text-white shadow-premium-lg backdrop-blur-xl"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.65 }}
            >
              <span className="flex size-9 items-center justify-center rounded-lg bg-brand-teal/25 text-brand-aqua">
                <HeartHandshake className="size-5" strokeWidth={2.1} />
              </span>
              <p className="mt-2.5 font-display text-sm font-bold leading-tight">Family-Owned</p>
              <p className="mt-0.5 text-xs leading-snug text-white/65">Local since 2008.</p>
            </motion.div>

            {/* LAYER 4 — cleaning-object accent (spray bottle), depth: fast */}
            <motion.div
              style={parallax ? { x: sprayX, y: sprayY, z: 140 } : undefined}
              className="absolute left-2 top-[44%] flex size-14 items-center justify-center rounded-2xl border border-white/15 bg-white/10 text-brand-aqua shadow-premium backdrop-blur-xl"
              animate={parallax ? { y: [0, -8, 0] } : undefined}
              transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
            >
              <SprayCan className="size-6" strokeWidth={1.9} />
            </motion.div>

            {/* LAYER 5 — sparkle particles, depth: independent */}
            <motion.span
              style={parallax ? { x: sparkX, y: sparkY, z: 170 } : undefined}
              className="absolute left-1/4 top-6 size-2 rounded-full bg-brand-aqua shadow-[0_0_12px_2px_var(--brand-aqua)]"
              animate={parallax ? { opacity: [0.4, 1, 0.4] } : undefined}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            />
            <motion.span
              style={parallax ? { x: sparkX, y: sparkY, z: 170 } : undefined}
              className="absolute left-1/3 top-[28%] size-1.5 rounded-full bg-white shadow-[0_0_10px_2px_rgba(255,255,255,0.7)]"
              animate={parallax ? { opacity: [0.3, 0.9, 0.3] } : undefined}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut", delay: 0.6 }}
            />
            <motion.span
              style={parallax ? { x: sparkX, y: sparkY, z: 170 } : undefined}
              className="absolute left-6 bottom-1/4 size-1.5 rounded-full bg-brand-aqua shadow-[0_0_10px_2px_var(--brand-aqua)]"
              animate={parallax ? { opacity: [0.3, 1, 0.3] } : undefined}
              transition={{ duration: 3.5, repeat: Infinity, ease: "easeInOut", delay: 1.1 }}
            />
          </motion.div>
        </div>

        {/* Mobile: lightweight floating depth (no cursor, gentle float) */}
        <div className="pointer-events-none absolute inset-0 z-0 lg:hidden" aria-hidden>
          <motion.span
            className="absolute right-4 top-[30%] size-2 rounded-full bg-brand-aqua shadow-[0_0_12px_2px_var(--brand-aqua)]"
            animate={{ y: [0, -10, 0], opacity: [0.4, 1, 0.4] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          />
          <motion.span
            className="absolute right-10 top-[22%] size-1.5 rounded-full bg-white shadow-[0_0_10px_2px_rgba(255,255,255,0.7)]"
            animate={{ y: [0, -7, 0], opacity: [0.3, 0.9, 0.3] }}
            transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 0.8 }}
          />
        </div>
      </Container>

      {/* Bottom fade into next section */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-background to-transparent" />

      {/* scroll hint */}
      <div className="pointer-events-none absolute inset-x-0 bottom-6 hidden justify-center lg:flex">
        <motion.div
          animate={{ y: [0, 6, 0] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
          className="flex flex-col items-center gap-1 text-white/50"
        >
          <span className="text-[0.65rem] font-semibold uppercase tracking-[0.2em]">Scroll</span>
          <span className="flex h-9 w-5 items-start justify-center rounded-full border border-white/25 p-1">
            <span className="h-2 w-1 rounded-full bg-white/60" />
          </span>
        </motion.div>
      </div>
    </section>
  );
}
