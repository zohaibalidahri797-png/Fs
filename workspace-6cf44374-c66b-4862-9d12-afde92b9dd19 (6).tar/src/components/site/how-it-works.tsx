"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { ClipboardList, MessageSquare, CalendarClock, Sofa } from "lucide-react";
import { Container, Section, SectionHeading } from "./section-primitives";

const STEPS = [
  {
    n: "01",
    icon: ClipboardList,
    title: "Request a Free Quote",
    text: "Send us your details or call (316) 477-0101. We'll gather the basics about your space and needs.",
  },
  {
    n: "02",
    icon: MessageSquare,
    title: "Discuss Your Cleaning Needs",
    text: "We talk through your priorities, problem areas, and schedule so we understand exactly what matters to you.",
  },
  {
    n: "03",
    icon: CalendarClock,
    title: "Schedule Your Service",
    text: "Pick a time that works for you. One-time, recurring, or project-based — we plan around your life or business.",
  },
  {
    n: "04",
    icon: Sofa,
    title: "Enjoy a Cleaner Space",
    text: "Our trusted team delivers a thorough, detail-oriented clean. Relax and enjoy the difference.",
  },
];

export function HowItWorks() {
  return (
    <Section id="how-it-works" className="bg-background">
      <Container>
        <SectionHeading
          eyebrow="How It Works"
          title={
            <>
              A simple, personal process —{" "}
              <span className="text-gradient-brand">start to spotless</span>
            </>
          }
          subtitle="No complicated booking. Just a clear, friendly path from your first request to a cleaner home or office."
        />

        {/* Desktop: horizontal flow */}
        <div className="mt-14 hidden lg:block">
          <div className="relative">
            <div className="absolute left-0 right-0 top-12 mx-12 h-px bg-gradient-to-r from-brand-teal/10 via-brand-teal/35 to-brand-teal/10" />
            <div className="grid grid-cols-4 gap-6">
              {STEPS.map((s, i) => (
                <motion.div
                  key={s.n}
                  initial={{ opacity: 0, y: 18 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-50px" }}
                  transition={{ duration: 0.45, delay: i * 0.08 }}
                  className="relative flex flex-col items-center text-center"
                >
                  <div className="relative z-10 flex size-24 items-center justify-center rounded-full border border-brand-teal/25 bg-card shadow-premium">
                    <s.icon className="size-9 text-brand-teal" strokeWidth={1.8} />
                    <span className="absolute -right-1 -top-1 flex size-8 items-center justify-center rounded-full bg-brand-navy font-display text-xs font-bold text-white">
                      {s.n}
                    </span>
                  </div>
                  <h3 className="mt-5 font-display text-lg font-bold tracking-tight text-foreground">
                    {s.title}
                  </h3>
                  <p className="mt-2 max-w-[220px] text-sm leading-relaxed text-muted-foreground">
                    {s.text}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* Mobile: vertical timeline */}
        <div className="mt-10 lg:hidden">
          <div className="relative pl-10">
            <div className="absolute left-[18px] top-2 bottom-2 w-px bg-gradient-to-b from-brand-teal/35 to-brand-teal/5" />
            <div className="flex flex-col gap-7">
              {STEPS.map((s, i) => (
                <motion.div
                  key={s.n}
                  initial={{ opacity: 0, x: 12 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, margin: "-40px" }}
                  transition={{ duration: 0.4, delay: i * 0.06 }}
                  className="relative"
                >
                  <div className="absolute -left-10 top-0 flex size-9 items-center justify-center rounded-full border border-brand-teal/25 bg-card text-brand-teal shadow-premium">
                    <s.icon className="size-4" strokeWidth={2} />
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-display text-sm font-bold text-brand-teal">{s.n}</span>
                    <h3 className="font-display text-base font-bold tracking-tight text-foreground">
                      {s.title}
                    </h3>
                  </div>
                  <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                    {s.text}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </Container>
    </Section>
  );
}
