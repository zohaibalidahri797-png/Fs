import * as React from "react";
import { Container, Section } from "./section-primitives";

export type LegalItem = { h: string; p: string[] };

/**
 * Renders a legal document as clean, readable prose (h2 + paragraphs).
 */
export function LegalContent({ items }: { items: LegalItem[] }) {
  return (
    <Section className="bg-background">
      <Container>
        <div className="mx-auto max-w-3xl space-y-8">
          {items.map((it) => (
            <div key={it.h}>
              <h2 className="font-display text-xl font-bold tracking-tight text-foreground">
                {it.h}
              </h2>
              {it.p.map((para, i) => (
                <p
                  key={i}
                  className="mt-2 text-sm leading-relaxed text-muted-foreground sm:text-base"
                >
                  {para}
                </p>
              ))}
            </div>
          ))}
        </div>
      </Container>
    </Section>
  );
}
