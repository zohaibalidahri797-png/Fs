import * as React from "react";
import { Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

/** Brand wordmark for Wichita Maid Service® | Clean Maid USA LLC. */
export function Logo({
  className,
  showTagline = true,
  variant = "light",
}: {
  className?: string;
  showTagline?: boolean;
  variant?: "light" | "onDark";
}) {
  const onDark = variant === "onDark";
  return (
    <span className={cn("flex items-center gap-2.5", className)}>
      <span
        className={cn(
          "relative flex size-9 items-center justify-center rounded-xl shadow-premium",
          onDark ? "bg-white/10 ring-1 ring-white/15" : "bg-brand-navy",
        )}
      >
        <Sparkles className={cn("size-5", onDark ? "text-brand-aqua" : "text-white")} strokeWidth={2.2} />
        <span className="absolute -right-0.5 -top-0.5 size-2.5 rounded-full bg-brand-aqua ring-2 ring-background" />
      </span>
      <span className="flex flex-col leading-none">
        <span
          className={cn(
            "font-display text-[1.02rem] font-bold tracking-tight",
            onDark ? "text-white" : "text-foreground",
          )}
        >
          Wichita Maid Service<sup className="text-[0.6em] text-brand-aqua">®</sup>
        </span>
        {showTagline ? (
          <span
            className={cn(
              "text-[0.6rem] font-semibold uppercase tracking-[0.24em]",
              onDark ? "text-white/55" : "text-muted-foreground",
            )}
          >
            Clean Maid USA LLC
          </span>
        ) : null}
      </span>
    </span>
  );
}
