"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Phone, CalendarCheck, X } from "lucide-react";
import { Button } from "@/components/ui/button";

export function MobileCtaBar() {
  const [dismissed, setDismissed] = React.useState(false);
  const [hidden, setHidden] = React.useState(false);

  // Hide when the quote section is in view so it never covers form fields.
  React.useEffect(() => {
    const el = document.getElementById("quote");
    if (!el) return;
    const io = new IntersectionObserver(
      ([entry]) => setHidden(entry.isIntersecting),
      { threshold: 0.08 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  const show = !dismissed && !hidden;

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          key="mobile-cta"
          initial={{ y: 90, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 90, opacity: 0 }}
          transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1], delay: 0.5 }}
          className="fixed inset-x-0 bottom-0 z-40 xl:hidden"
          style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
        >
          <div className="relative border-t border-border/70 bg-background/95 backdrop-blur-xl shadow-[0_-8px_24px_-12px_rgba(0,0,0,0.18)]">
            <button
              type="button"
              onClick={() => setDismissed(true)}
              aria-label="Dismiss"
              className="absolute -top-3 right-4 flex size-7 items-center justify-center rounded-full border border-border bg-background text-muted-foreground shadow-premium"
            >
              <X className="size-3.5" />
            </button>
            <div className="flex items-stretch gap-2 p-2.5">
              <Button
                asChild
                variant="outline"
                className="flex-1 gap-2 border-brand-teal/40 text-brand-teal"
              >
                <a href="tel:3164770101">
                  <Phone className="size-4" />
                  Call Now
                </a>
              </Button>
              <Button asChild className="flex-1 gap-2 bg-brand-navy shadow-premium hover:bg-brand-navy/90">
                <a href="/contact">
                  <CalendarCheck className="size-4" />
                  Get Quote
                </a>
              </Button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
