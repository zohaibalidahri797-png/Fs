import * as React from "react";
import Link from "next/link";
import { ChevronRight, ArrowRight } from "lucide-react";
import { Header } from "./header";
import { Footer } from "./footer";
import { MobileCtaBar } from "./mobile-cta-bar";
import { Container, Eyebrow } from "./section-primitives";

/**
 * Shared layout for dedicated inner pages: header + page hero + content + footer.
 * Keeps the homepage fully intact while giving each route a focused, SEO-friendly page.
 */
export function PageLayout({
  eyebrow,
  title,
  intro,
  children,
}: {
  eyebrow: string;
  title: React.ReactNode;
  intro?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <Header />
      <main className="flex-1">
        <PageHero eyebrow={eyebrow} title={title} intro={intro} />
        {children}
      </main>
      <Footer />
      <MobileCtaBar />
    </div>
  );
}

function PageHero({
  eyebrow,
  title,
  intro,
}: {
  eyebrow: string;
  title: React.ReactNode;
  intro?: React.ReactNode;
}) {
  return (
    <section className="relative isolate overflow-hidden bg-brand-navy pt-[68px] lg:pt-[76px]">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -left-24 top-0 size-[420px] rounded-full bg-brand-teal/15 blur-[130px]" />
        <div className="absolute -right-20 bottom-0 size-[360px] rounded-full bg-brand-aqua/10 blur-[130px]" />
        <div className="absolute inset-0 bg-grid-light opacity-[0.06]" />
      </div>
      <Container className="relative py-14 sm:py-16 lg:py-20">
        {/* Breadcrumb */}
        <nav aria-label="Breadcrumb" className="mb-5 flex items-center gap-1.5 text-xs font-medium text-white/55">
          <Link href="/" className="transition-colors hover:text-brand-aqua">Home</Link>
          <ChevronRight className="size-3" />
          <span className="text-white/80">{eyebrow}</span>
        </nav>
        <Eyebrow tone="aqua">{eyebrow}</Eyebrow>
        <h1 className="mt-4 max-w-3xl font-display text-3xl font-bold leading-[1.08] tracking-tight text-white sm:text-4xl lg:text-5xl">
          {title}
        </h1>
        {intro ? (
          <p className="mt-4 max-w-2xl text-base leading-relaxed text-white/70 sm:text-lg">
            {intro}
          </p>
        ) : null}
      </Container>
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-background to-transparent" />
    </section>
  );
}

/** Compact CTA strip used at the bottom of inner pages. */
export function PageCta({
  title = "Ready for a cleaner space?",
  copy = "Get a free, personalized quote from our Wichita team — for your home or business.",
}: {
  title?: string;
  copy?: string;
}) {
  return (
    <section className="relative overflow-hidden bg-cream">
      <Container className="py-16">
        <div className="flex flex-col items-center justify-between gap-6 rounded-2xl border border-border/70 bg-card p-8 text-center shadow-premium sm:p-10 lg:flex-row lg:text-left">
          <div>
            <h2 className="font-display text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
              {title}
            </h2>
            <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted-foreground sm:text-base">
              {copy}
            </p>
          </div>
          <div className="flex shrink-0 flex-col gap-2 sm:flex-row">
            <Link
              href="/contact"
              className="inline-flex h-11 items-center justify-center gap-2 rounded-md bg-brand-navy px-6 text-sm font-semibold text-white shadow-premium transition-colors hover:bg-brand-navy/90"
            >
              Get a Free Quote
              <ArrowRight className="size-4" />
            </Link>
            <a
              href="tel:3164770101"
              className="inline-flex h-11 items-center justify-center gap-2 rounded-md border border-border bg-background px-6 text-sm font-semibold text-foreground transition-colors hover:bg-brand-mist"
            >
              (316) 477-0101
            </a>
          </div>
        </div>
      </Container>
    </section>
  );
}
