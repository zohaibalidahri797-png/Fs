"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  CalendarCheck,
  Phone,
  Mail,
  ShieldCheck,
  Clock,
  Sparkles,
  Check,
  PartyPopper,
  ArrowRight,
  ArrowLeft,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Container, Section, Eyebrow } from "./section-primitives";
import { cn } from "@/lib/utils";

const SERVICE_OPTIONS = [
  "Residential Cleaning",
  "Office & Commercial Cleaning",
  "Move-In / Move-Out Cleaning",
  "Post-Construction Cleaning",
  "Deep Cleaning",
  "Recurring Cleaning",
  "Customized Cleaning Services",
  "Not sure yet — help me decide",
];
const PROPERTY_OPTIONS = [
  "Single-family home",
  "Apartment / Condo",
  "Townhome",
  "Office / Workspace",
  "Retail / Commercial",
  "Other",
];
const TIME_OPTIONS = ["Morning", "Afternoon", "Evening", "Anytime", "After-hours"];
const SIZE_OPTIONS = [
  "Small — up to 1,000 sq ft",
  "Medium — 1,000–2,000 sq ft",
  "Large — 2,000–3,000 sq ft",
  "Extra large — 3,000+ sq ft",
  "Not sure",
];

type FormState = {
  name: string;
  phone: string;
  email: string;
  service: string;
  propertyType: string;
  propertySize: string;
  preferredDate: string;
  preferredTime: string;
  message: string;
};

const EMPTY: FormState = {
  name: "",
  phone: "",
  email: "",
  service: "",
  propertyType: "",
  propertySize: "",
  preferredDate: "",
  preferredTime: "",
  message: "",
};

const PERKS = [
  { icon: ShieldCheck, text: "Insured & background-checked team" },
  { icon: Clock, text: "Flexible scheduling & same-day where open" },
  { icon: Sparkles, text: "Personalized plan, not a generic package" },
  { icon: CalendarCheck, text: "Free walkthrough & no-obligation quote" },
];

const STEPS = ["Service", "Property", "Schedule", "Contact"];

export function QuoteForm({ showHeading = true }: { showHeading?: boolean } = {}) {
  const [step, setStep] = React.useState(0); // 0..3
  const [data, setData] = React.useState<FormState>(EMPTY);
  const [errors, setErrors] = React.useState<Record<string, string>>({});
  const [submitting, setSubmitting] = React.useState(false);
  const [done, setDone] = React.useState(false);
  const [minDate, setMinDate] = React.useState("");

  // Set min date client-side to avoid SSR/client hydration mismatch.
  React.useEffect(() => {
    setMinDate(new Date().toISOString().split("T")[0]);
  }, []);

  const set = (k: keyof FormState, v: string) =>
    setData((d) => ({ ...d, [k]: v }));

  const validateStep = (s: number) => {
    const e: Record<string, string> = {};
    if (s === 0) {
      if (!data.service) e.service = "Please choose a service.";
    } else if (s === 1) {
      if (!data.propertyType) e.propertyType = "Please choose a property type.";
    } else if (s === 2) {
      if (data.preferredDate && Number.isNaN(Date.parse(data.preferredDate)))
        e.preferredDate = "Invalid date.";
    } else if (s === 3) {
      if (!data.name.trim()) e.name = "Please enter your name.";
      if (!data.phone.trim()) e.phone = "Please enter your phone number.";
      if (!data.email.trim()) e.email = "Please enter your email.";
      else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email))
        e.email = "Please enter a valid email.";
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const next = () => {
    if (validateStep(step)) setStep((s) => Math.min(STEPS.length - 1, s + 1));
  };
  const back = () => setStep((s) => Math.max(0, s - 1));

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateStep(3)) return;
    setSubmitting(true);
    try {
      const res = await fetch("/api/quote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const j = await res.json().catch(() => null);
        if (j?.fields) setErrors(j.fields);
        else setErrors({ submit: "Something went wrong. Please call (316) 477-0101." });
      } else {
        setDone(true);
      }
    } catch {
      setErrors({ submit: "Network error. Please call (316) 477-0101." });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Section id="quote" className="bg-background">
      <Container>
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-12 lg:gap-14">
          {/* Left — persuasive copy */}
          <div className="lg:col-span-5">
            {showHeading && (
              <>
                <Eyebrow>Free Quote</Eyebrow>
                <h2 className="mt-4 font-display text-3xl font-bold leading-[1.08] tracking-tight sm:text-4xl lg:text-[2.75rem]">
                  Get your free, personalized quote.
                </h2>
                <p className="mt-4 max-w-md text-base leading-relaxed text-muted-foreground">
                  Tell us about your space and what matters most to you. We&apos;ll
                  walk it with you, build a cleaning plan around your needs, and
                  send a clear, no-obligation quote.
                </p>
              </>
            )}

            <ul className={`${showHeading ? "mt-7" : "mt-0"} space-y-3`}>
              {PERKS.map((p) => (
                <li key={p.text} className="flex items-center gap-3">
                  <span className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-brand-teal/10 text-brand-teal">
                    <p.icon className="size-5" strokeWidth={2.1} />
                  </span>
                  <span className="text-sm leading-relaxed text-foreground/80">
                    {p.text}
                  </span>
                </li>
              ))}
            </ul>

            <div className="mt-8 flex items-start gap-3 border-t border-border/70 pt-6">
              <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-brand-teal/10 text-brand-teal">
                <Phone className="size-5" />
              </span>
              <div className="text-sm leading-tight">
                <div className="text-muted-foreground">Prefer to talk?</div>
                <a
                  href="tel:3164770101"
                  className="font-display text-lg font-bold text-foreground hover:text-brand-teal"
                >
                  (316) 477-0101
                </a>
                <a
                  href="mailto:CleanMaidUS@gmail.com"
                  className="mt-1 flex items-center gap-1.5 text-sm text-muted-foreground hover:text-brand-teal"
                >
                  <Mail className="size-3.5" />
                  CleanMaidUS@gmail.com
                </a>
              </div>
            </div>
          </div>

          {/* Right — multi-step form card */}
          <div className="lg:col-span-7">
            <div className="overflow-hidden rounded-2xl border border-border/70 bg-card p-6 shadow-premium-lg sm:p-8">
              <AnimatePresence mode="wait">
                {done ? (
                  <motion.div
                    key="done"
                    initial={{ opacity: 0, x: 40 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                    className="flex flex-col items-center py-10 text-center"
                  >
                    <motion.span
                      initial={{ scale: 0.6, rotate: -20, opacity: 0 }}
                      animate={{ scale: 1, rotate: 0, opacity: 1 }}
                      transition={{ delay: 0.1, type: "spring", stiffness: 200, damping: 14 }}
                      className="flex size-16 items-center justify-center rounded-full bg-brand-teal text-white shadow-teal"
                    >
                      <PartyPopper className="size-8" />
                    </motion.span>
                    <h3 className="mt-5 font-display text-2xl font-bold tracking-tight">
                      Your quote request is in!
                    </h3>
                    <p className="mt-2 max-w-md text-sm leading-relaxed text-muted-foreground">
                      Thanks, {data.name.split(" ")[0] || "there"} — we&apos;ve
                      received your request for{" "}
                      <span className="font-medium text-foreground">{data.service}</span>
                      . A member of our Wichita team will reach out shortly to
                      confirm details and schedule your free walkthrough.
                    </p>
                    <div className="mt-6 flex flex-col gap-2 sm:flex-row">
                      <Button asChild variant="outline" className="gap-2">
                        <a href="tel:3164770101">
                          <Phone className="size-4" />
                          Call (316) 477-0101
                        </a>
                      </Button>
                      <Button
                        variant="ghost"
                        onClick={() => {
                          setData(EMPTY);
                          setErrors({});
                          setStep(0);
                          setDone(false);
                        }}
                      >
                        Submit another request
                      </Button>
                    </div>
                  </motion.div>
                ) : (
                  <motion.form
                    key="form"
                    onSubmit={onSubmit}
                    initial={{ opacity: 1 }}
                    exit={{ opacity: 0, x: -30 }}
                    transition={{ duration: 0.3 }}
                    className="flex flex-col gap-5"
                  >
                    {/* Progress indicator */}
                    <div>
                      <div className="mb-2 flex items-center justify-between">
                        <span className="text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">
                          Step {step + 1} of {STEPS.length} — {STEPS[step]}
                        </span>
                        <span className="text-xs font-medium text-brand-teal">
                          {Math.round(((step + 1) / STEPS.length) * 100)}%
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        {STEPS.map((_, i) => (
                          <span
                            key={i}
                            className={cn(
                              "h-1.5 flex-1 rounded-full transition-colors duration-300",
                              i < step
                                ? "bg-brand-teal"
                                : i === step
                                  ? "bg-brand-teal"
                                  : "bg-muted",
                            )}
                          />
                        ))}
                      </div>
                    </div>

                    <AnimatePresence mode="wait">
                      <motion.div
                        key={step}
                        initial={{ opacity: 0, x: 24 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -24 }}
                        transition={{ duration: 0.3, ease: "easeOut" }}
                      >
                        {step === 0 && (
                          <div className="grid grid-cols-1 gap-4">
                            <Field label="Service" error={errors.service} required>
                              <SelectField
                                value={data.service}
                                onChange={(v) => set("service", v)}
                                placeholder="Choose a service"
                                options={SERVICE_OPTIONS}
                              />
                            </Field>
                          </div>
                        )}

                        {step === 1 && (
                          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                            <Field label="Property type" error={errors.propertyType} required>
                              <SelectField
                                value={data.propertyType}
                                onChange={(v) => set("propertyType", v)}
                                placeholder="Choose a property"
                                options={PROPERTY_OPTIONS}
                              />
                            </Field>
                            <Field label="Property size (optional)" error={errors.propertySize}>
                              <SelectField
                                value={data.propertySize}
                                onChange={(v) => set("propertySize", v)}
                                placeholder="Choose a size"
                                options={SIZE_OPTIONS}
                              />
                            </Field>
                          </div>
                        )}

                        {step === 2 && (
                          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                            <Field label="Preferred date (optional)" error={errors.preferredDate}>
                              <Input
                                type="date"
                                value={data.preferredDate}
                                onChange={(e) => set("preferredDate", e.target.value)}
                                min={minDate || undefined}
                                aria-describedby="preferred-date-help"
                                className="h-11"
                              />
                              <p id="preferred-date-help" className="text-xs text-muted-foreground">
                                Select a preferred date — we&apos;ll confirm availability with you.
                              </p>
                            </Field>
                            <Field label="Preferred time (optional)" error={errors.preferredTime}>
                              <SelectField
                                value={data.preferredTime}
                                onChange={(v) => set("preferredTime", v)}
                                placeholder="Choose a time"
                                options={TIME_OPTIONS}
                              />
                            </Field>
                          </div>
                        )}

                        {step === 3 && (
                          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                            <Field label="Full name" error={errors.name} required>
                              <Input
                                value={data.name}
                                onChange={(e) => set("name", e.target.value)}
                                placeholder="Jane Smith"
                                autoComplete="name"
                                className="h-11"
                              />
                            </Field>
                            <Field label="Phone" error={errors.phone} required>
                              <Input
                                type="tel"
                                value={data.phone}
                                onChange={(e) => set("phone", e.target.value)}
                                placeholder="(316) 555-0123"
                                autoComplete="tel"
                                className="h-11"
                              />
                            </Field>
                            <Field label="Email" error={errors.email} required className="sm:col-span-2">
                              <Input
                                type="email"
                                value={data.email}
                                onChange={(e) => set("email", e.target.value)}
                                placeholder="you@example.com"
                                autoComplete="email"
                                className="h-11"
                              />
                            </Field>
                            <Field label="Message / additional requirements (optional)" className="sm:col-span-2">
                              <Textarea
                                value={data.message}
                                onChange={(e) => set("message", e.target.value)}
                                placeholder="Tell us about priorities, problem areas, pets, access, timing…"
                                className="min-h-24"
                              />
                            </Field>
                          </div>
                        )}
                      </motion.div>
                    </AnimatePresence>

                    {errors.submit && (
                      <p className="text-sm text-destructive">{errors.submit}</p>
                    )}

                    <div className="flex flex-col gap-2 sm:flex-row sm:justify-between">
                      {step > 0 ? (
                        <Button type="button" variant="outline" onClick={back} className="gap-2">
                          <ArrowLeft className="size-4" />
                          Back
                        </Button>
                      ) : (
                        <span />
                      )}
                      {step < STEPS.length - 1 ? (
                        <Button type="button" onClick={next} className="gap-2 bg-brand-navy shadow-premium hover:bg-brand-navy/90">
                          Continue
                          <ArrowRight className="size-4" />
                        </Button>
                      ) : (
                        <Button type="submit" disabled={submitting} className="gap-2 bg-brand-navy shadow-premium hover:bg-brand-navy/90">
                          {submitting ? "Sending…" : "Request My Free Quote"}
                          {submitting ? null : <Check className="size-4" />}
                        </Button>
                      )}
                    </div>
                  </motion.form>
                )}
              </AnimatePresence>
            </div>
            <a
              href="tel:3164770101"
              className="mt-3 flex items-center justify-center gap-1.5 text-sm font-semibold text-brand-teal hover:underline lg:hidden"
            >
              <Phone className="size-4" />
              Or call (316) 477-0101
              <ArrowRight className="size-4" />
            </a>
          </div>
        </div>
      </Container>
    </Section>
  );
}

function Field({
  label,
  error,
  required,
  className,
  children,
}: {
  label: string;
  error?: string;
  required?: boolean;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <div className={cn("flex flex-col gap-1.5", className)}>
      <Label className="text-sm font-medium text-foreground">
        {label}
        {required && <span className="text-destructive"> *</span>}
      </Label>
      {children}
      {error && <p className="text-xs text-destructive">{error}</p>}
    </div>
  );
}

function SelectField({
  value,
  onChange,
  placeholder,
  options,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
  options: string[];
}) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className="h-11 w-full bg-background">
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent>
        {options.map((o) => (
          <SelectItem key={o} value={o}>
            {o}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
