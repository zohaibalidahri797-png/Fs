/**
 * Genuine customer reviews.
 *
 * Replace or extend this array with REAL, verified review content (for example,
 * exported from your Google Business Profile). Each field must be truthful:
 *
 *   - name:   the customer's name (only if you have permission / it's public)
 *   - text:   the customer's actual review text
 *   - rating: a real 1–5 rating, only if one exists
 *   - date:   the real review date (ISO string, e.g. "2024-08-15")
 *   - source: where it came from, e.g. "Google"
 *
 * Until real reviews are available, LEAVE THIS EMPTY. Do NOT fabricate names,
 * review text, ratings, dates, or counts — the Reviews section will simply show
 * the "Read Our Google Reviews" call-to-action instead, which is honest and
 * complete-looking on its own.
 */
export type Review = {
  name: string;
  text: string;
  rating?: number;
  date?: string;
  source?: string;
};

export const REVIEWS: Review[] = [];
