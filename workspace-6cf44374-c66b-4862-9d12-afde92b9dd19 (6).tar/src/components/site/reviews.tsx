"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { ArrowUpRight, ShieldCheck, BadgeCheck, Sparkles, Users, Quote, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Container, Section, Eyebrow } from "./section-primitives";
import { REVIEWS } from "./reviews-data";
import { cn } from "@/lib/utils";

const GOOGLE_REVIEWS_URL =
  "https://www.google.com/maps/search/?api=1&query=Wichita+Maid+Service+Clean+Maid+USA+Wichita+KS";

const TRUST = [
  { icon: Sparkles, label: "Est. 2008" },
  { icon: ShieldCheck, label: "Insured" },
  { icon: BadgeCheck, label: "Background-checked" },
  { icon: Users, label: "Family-owned" },
];

function GoogleG({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} aria-hidden>
      <path fill="#4285F4" d="M45.12 24.5c0-1.56-.14-3.06-.4-4.5H24v8.51h11.84c-.51 2.75-2.06 5.08-4.39 6.64v5.52h7.09c4.15-3.83 6.58-9.47 6.58-16.17z" />
      <path fill="#34A853" d="M24 46c5.92 0 10.89-1.96 14.52-5.31l-7.09-5.52c-1.96 1.32-4.47 2.1-7.43 2.1-5.71 0-10.54-3.86-12.27-9.05H4.46v5.7C8.06 41.07 15.4 46 24 46z" />
      <path fill="#FBBC05" d="M11.73 28.22c-.44-1.32-.69-2.73-.69-4.22s.25-2.9.69-4.22v-5.7H4.46A17.97 17.97 0 0 0 2 24c0 2.9.69 5.64 1.9 8.04l7.83-5.82z" />
      <path fill="#EA4335" d="M24 10.75c3.21 0 6.09 1.1 8.36 2.91l6.26-4.86C34.88 4.03 29.9 2 24 2 15.4 2 8.06 6.93 4.46 14.08l7.27 5.82c1.73-5.19 6.56-9.05 12.27-9.05z" />
    </svg>
  );
}

export function Reviews({ showHeading = true }: { showHeading?: boolean } = {}) {
  return (
    <Section id="reviews" className="relative overflow-hidden bg-brand-navy">
      {/* atmosphere */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -left-24 top-0 size-[420px] rounded-full bg-brand-teal/15 blur-[130px]" />
        <div className="absolute -right-20 bottom-0 size-[360px] rounded-full bg-brand-aqua/10 blur-[130px]" />
        <div className="absolute inset-0 bg-grid-light opacity-[0.06]" />
      </div>

      <Container className="relative">
        {showHeading && (
          <div className="mx-auto max-w-3xl text-center">
            <div className="flex justify-center">
              <Eyebrow tone="aqua">Customer Feedback</Eyebrow>
            </div>
            <h2 className="mt-4 font-display text-3xl font-bold leading-[1.08] tracking-tight text-white sm:text-4xl lg:text-[2.75rem]">
              Trusted by Wichita{" "}
              <span className="text-gradient-brand">home &amp; business owners</span>
            </h2>
            <p className="mt-4 mx-auto max-w-2xl text-base leading-relaxed text-white/70 sm:text-lg">
              See real customer feedback and learn more about the Clean Maid USA
              experience — verified reviews, directly on Google.
            </p>
          </div>
        )}

        {/* Genuine review cards (render only when real reviews are present in reviews-data.ts) */}
        {REVIEWS.length > 0 && (
          <div className="mx-auto mt-12 grid max-w-5xl gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {REVIEWS.slice(0, 3).map((r, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.45, delay: (i % 3) * 0.06 }}
                className="flex flex-col rounded-2xl border border-white/12 bg-white/[0.04] p-6 shadow-premium backdrop-blur-xl"
              >
                <Quote className="size-7 text-brand-aqua/70" strokeWidth={1.5} />
                {typeof r.rating === "number" && (
                  <div
                    className="mt-3 flex gap-0.5"
                    aria-label={`${r.rating} out of 5 stars`}
                  >
                    {Array.from({ length: 5 }).map((_, s) => (
                      <Star
                        key={s}
                        className={cn(
                          "size-4",
                          s < (r.rating as number)
                            ? "fill-brand-aqua text-brand-aqua"
                            : "text-white/20",
                        )}
                      />
                    ))}
                  </div>
                )}
                <p className="mt-3 flex-1 text-sm leading-relaxed text-white/85">
                  &ldquo;{r.text}&rdquo;
                </p>
                <div className="mt-4 border-t border-white/10 pt-3 text-xs text-white/55">
                  <span className="font-semibold text-white/80">{r.name}</span>
                  {r.date && (
                    <span>
                      {" · "}
                      {new Date(r.date).toLocaleDateString("en-US", {
                        year: "numeric",
                        month: "short",
                        day: "numeric",
                      })}
                    </span>
                  )}
                  {r.source && <span> · {r.source}</span>}
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Premium Google reviews card */}
        <motion.div
          initial={{ opacity: 0, y: 22 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.55, ease: "easeOut" }}
          className="relative mx-auto mt-12 max-w-3xl overflow-hidden rounded-3xl border border-white/12 bg-white/[0.04] p-8 text-center shadow-premium-lg backdrop-blur-xl sm:p-12"
        >
          <span className="pointer-events-none absolute left-6 top-6 text-white/10">
            <Quote className="size-14" strokeWidth={1.5} />
          </span>
          <span className="pointer-events-none absolute bottom-6 right-6 rotate-180 text-white/10">
            <Quote className="size-14" strokeWidth={1.5} />
          </span>

          <GoogleG className="mx-auto size-14" />
          <p className="mt-5 font-display text-xl font-bold tracking-tight text-white">
            Read what Wichita customers are saying
          </p>
          <p className="mt-2 text-sm leading-relaxed text-white/65">
            Real customer feedback lives on Google — open our profile to read
            verified reviews from the homes and businesses we serve.
          </p>

          <div className="mt-7 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Button asChild size="lg" className="gap-2 bg-white text-brand-navy shadow-premium hover:bg-white/90">
              <a href={GOOGLE_REVIEWS_URL} target="_blank" rel="noopener noreferrer">
                <GoogleG className="size-4" />
                Read Our Google Reviews
                <ArrowUpRight className="size-4" />
              </a>
            </Button>
          </div>

          <p className="mt-6 text-xs font-medium uppercase tracking-[0.18em] text-white/45">
            Real feedback. No fabricated testimonials.
          </p>
        </motion.div>

        {/* trust row */}
        <div className="mx-auto mt-10 flex max-w-2xl flex-wrap items-center justify-center gap-x-6 gap-y-3">
          {TRUST.map((t) => (
            <span
              key={t.label}
              className="inline-flex items-center gap-2 text-sm font-medium text-white/70"
            >
              <t.icon className="size-4 text-brand-aqua" strokeWidth={2.1} />
              {t.label}
            </span>
          ))}
        </div>
      </Container>
    </Section>
  );
}
