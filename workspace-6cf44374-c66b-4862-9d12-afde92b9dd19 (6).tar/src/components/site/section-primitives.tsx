import * as React from "react";
import { cn } from "@/lib/utils";

/** Centered max-width container with responsive horizontal padding. */
export function Container({
  className,
  ...props
}: React.ComponentProps<"div">) {
  return (
    <div
      className={cn("mx-auto w-full max-w-7xl px-5 sm:px-6 lg:px-8", className)}
      {...props}
    />
  );
}

/** Small uppercase eyebrow label with a leading mark. */
export function Eyebrow({
  className,
  children,
  tone = "teal",
}: {
  className?: string;
  children: React.ReactNode;
  tone?: "teal" | "aqua" | "navy" | "muted";
}) {
  const text =
    tone === "teal"
      ? "text-brand-teal"
      : tone === "aqua"
        ? "text-brand-aqua"
        : tone === "navy"
          ? "text-brand-navy"
          : "text-muted-foreground";
  const bar =
    tone === "teal"
      ? "bg-brand-teal/55"
      : tone === "aqua"
        ? "bg-brand-aqua/60"
        : tone === "navy"
          ? "bg-brand-navy/45"
          : "bg-muted-foreground/40";
  return (
    <span
      className={cn(
        "inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em]",
        text,
        className,
      )}
    >
      <span className={cn("h-px w-6", bar)} />
      {children}
    </span>
  );
}

/** Reusable section heading block (eyebrow + title + optional subtitle). */
export function SectionHeading({
  eyebrow,
  title,
  subtitle,
  align = "center",
  tone = "teal",
  className,
  titleClassName,
}: {
  eyebrow?: string;
  title: React.ReactNode;
  subtitle?: React.ReactNode;
  align?: "center" | "left";
  tone?: "teal" | "aqua" | "navy" | "muted";
  className?: string;
  titleClassName?: string;
}) {
  return (
    <div
      className={cn(
        "flex flex-col gap-4",
        align === "center" ? "items-center text-center" : "items-start text-left",
        className,
      )}
    >
      {eyebrow ? <Eyebrow tone={tone}>{eyebrow}</Eyebrow> : null}
      <h2
        className={cn(
          "font-display text-3xl font-bold leading-[1.08] tracking-tight sm:text-4xl lg:text-[2.6rem]",
          align === "center" && "mx-auto max-w-3xl",
          titleClassName,
        )}
      >
        {title}
      </h2>
      {subtitle ? (
        <p
          className={cn(
            "max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg",
            align === "center" && "mx-auto",
          )}
        >
          {subtitle}
        </p>
      ) : null}
    </div>
  );
}

/** Section wrapper with vertical rhythm + optional id for anchor nav. */
export function Section({
  id,
  className,
  children,
  ...props
}: React.ComponentProps<"section">) {
  return (
    <section
      id={id}
      className={cn("scroll-mt-24 py-20 sm:py-24 lg:py-28", className)}
      {...props}
    >
      {children}
    </section>
  );
}
