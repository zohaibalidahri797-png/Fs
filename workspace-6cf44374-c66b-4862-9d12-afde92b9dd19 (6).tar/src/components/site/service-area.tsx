"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { MapPin, Navigation, Phone, Mail, ArrowRight, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Container, Section, SectionHeading, Eyebrow } from "./section-primitives";

const AREAS = [
  "Wichita",
  "Andover",
  "Derby",
  "Maize",
  "Goddard",
  "Park City",
  "Haysville",
  "Bel Aire",
];

const MAP_QUERY = "1020 East English Street, Suite A1, Wichita, KS 67211";
const MAP_EMBED = `https://maps.google.com/maps?q=${encodeURIComponent(
  MAP_QUERY,
)}&z=12&output=embed`;
const MAP_LINK = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
  MAP_QUERY,
)}`;

export function ServiceArea() {
  return (
    <Section id="service-area" className="bg-background">
      <Container>
        <SectionHeading
          eyebrow="Service Areas"
          title={
            <>
              Proudly serving{" "}
              <span className="text-gradient-brand">Wichita &amp; nearby</span>
            </>
          }
          subtitle="Based right here in Wichita, we clean for homes and businesses across the city and its surrounding communities. Don't see your area? Just ask — we likely cover it."
        />

        <div className="mt-12 grid grid-cols-1 gap-8 lg:grid-cols-2 lg:items-stretch">
          {/* Left — highlights + address */}
          <div className="flex flex-col">
            <Eyebrow tone="aqua">Where we clean</Eyebrow>
            <h3 className="mt-3 font-display text-2xl font-bold tracking-tight">
              Trusted across the Wichita metro
            </h3>
            <p className="mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
              From central Wichita to its surrounding suburbs, our local team is
              never far away. These are some of the communities we serve
              regularly.
            </p>

            <div className="mt-6 flex flex-wrap gap-2.5">
              {AREAS.map((a, i) => (
                <motion.span
                  key={a}
                  initial={{ opacity: 0, scale: 0.92 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.3, delay: (i % 4) * 0.04 }}
                  whileHover={{ scale: 1.05 }}
                  className="inline-flex cursor-default items-center gap-1.5 rounded-full border border-border/70 bg-card px-3.5 py-1.5 text-sm font-medium text-foreground/80 transition-shadow duration-300 hover:border-brand-teal/40 hover:shadow-[0_0_0_3px_color-mix(in_oklch,var(--brand-teal)_16%,transparent),0_8px_22px_-12px_color-mix(in_oklch,var(--brand-teal)_38%,transparent)] hover:text-brand-teal"
                >
                  <MapPin className="size-3.5 text-brand-aqua" />
                  {a}
                </motion.span>
              ))}
              <span className="inline-flex items-center gap-1.5 rounded-full border border-dashed border-brand-teal/40 bg-brand-teal/[0.04] px-3.5 py-1.5 text-sm font-medium text-brand-teal">
                <Navigation className="size-3.5" />
                + nearby areas
              </span>
            </div>

            {/* Address card */}
            <div className="mt-8 rounded-2xl border border-border/70 bg-card p-5 shadow-premium">
              <div className="flex items-start gap-3">
                <span className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-brand-teal/10 text-brand-teal">
                  <MapPin className="size-5" strokeWidth={2.1} />
                </span>
                <div className="min-w-0">
                  <div className="text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">
                    Our Wichita location
                  </div>
                  <div className="mt-1 font-display text-base font-bold leading-tight text-foreground">
                    1020 East English Street, Suite A1
                  </div>
                  <div className="text-sm text-foreground/75">Wichita, KS 67211</div>
                  <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
                    <span className="inline-flex items-center gap-1.5">
                      <Phone className="size-3.5 text-brand-teal" />
                      <a href="tel:3164770101" className="hover:text-brand-teal">(316) 477-0101</a>
                    </span>
                    <span className="inline-flex items-center gap-1.5">
                      <Mail className="size-3.5 text-brand-teal" />
                      <a href="mailto:CleanMaidUS@gmail.com" className="hover:text-brand-teal">CleanMaidUS@gmail.com</a>
                    </span>
                  </div>
                </div>
              </div>
              <div className="mt-4 flex flex-col gap-2 sm:flex-row">
                <Button asChild className="gap-2 bg-brand-navy shadow-premium hover:bg-brand-navy/90">
                  <a href="/contact">
                    Get a Free Quote
                    <ArrowRight className="size-4" />
                  </a>
                </Button>
                <Button asChild variant="outline" className="gap-2">
                  <a href={MAP_LINK} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="size-4" />
                    Open in Google Maps
                  </a>
                </Button>
              </div>
            </div>
          </div>

          {/* Right — map */}
          <div className="relative">
            <div className="relative h-full min-h-[360px] overflow-hidden rounded-2xl border border-border/70 bg-card shadow-premium-lg">
              <iframe
                title="Wichita Maid Service location map — 1020 East English Street, Wichita, KS"
                className="absolute inset-0 size-full"
                style={{ filter: "saturate(0.9) contrast(1.02)" }}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                src={MAP_EMBED}
              />
              <div className="pointer-events-none absolute inset-0 ring-1 ring-inset ring-brand-navy/10" />
              {/* Animated location marker */}
              <div className="pointer-events-none absolute left-1/2 top-8 flex -translate-x-1/2 flex-col items-center gap-1.5">
                <span className="relative flex size-5">
                  <span className="absolute inline-flex size-full animate-ping rounded-full bg-brand-teal/60" />
                  <span className="relative inline-flex size-5 items-center justify-center rounded-full bg-brand-teal text-white ring-2 ring-background">
                    <MapPin className="size-3" strokeWidth={2.4} />
                  </span>
                </span>
                <span className="rounded-full border border-border/70 bg-background/90 px-2.5 py-0.5 text-[0.68rem] font-semibold text-brand-navy shadow-premium backdrop-blur">
                  Wichita, KS
                </span>
              </div>
              {/* Overlay button */}
              <a
                href={MAP_LINK}
                target="_blank"
                rel="noopener noreferrer"
                className="absolute bottom-4 left-4 inline-flex items-center gap-2 rounded-full border border-border/70 bg-background/90 px-4 py-2 text-sm font-semibold text-brand-navy shadow-premium backdrop-blur transition-colors hover:bg-background"
              >
                <ExternalLink className="size-4 text-brand-teal" />
                Open in Google Maps
              </a>
            </div>
          </div>
        </div>
      </Container>
    </Section>
  );
}
