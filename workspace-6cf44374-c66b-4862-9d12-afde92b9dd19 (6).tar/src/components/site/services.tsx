"use client";

import * as React from "react";
import { motion } from "framer-motion";
import {
  Home,
  Building2,
  PackageCheck,
  HardHat,
  Sparkles,
  CalendarClock,
  SlidersHorizontal,
  ArrowRight,
  CalendarCheck,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Container, Section, SectionHeading } from "./section-primitives";
import { SmartImage } from "./smart-image";

type Service = {
  icon: React.ComponentType<{ className?: string; strokeWidth?: number }>;
  title: string;
  tag: string;
  image: string;
  alt: string;
  description: string;
};

const SERVICES: Service[] = [
  {
    icon: Home,
    title: "Residential Cleaning",
    tag: "Homes",
    image: "/images/residential-home.jpg",
    alt: "Spotless, sunlit Wichita living room after a professional residential cleaning",
    description:
      "Tailored home cleaning that fits your routine — so you come home to comfort every time.",
  },
  {
    icon: Building2,
    title: "Office & Commercial Cleaning",
    tag: "Business",
    image: "/images/commercial-office.jpg",
    alt: "Pristine, modern Wichita office space after professional commercial cleaning",
    description:
      "Consistent, professional cleaning that keeps your workplace healthy and welcoming.",
  },
  {
    icon: PackageCheck,
    title: "Move-In / Move-Out Cleaning",
    tag: "Transitions",
    image: "/images/service-move-in-out.jpg",
    alt: "Freshly cleaned, empty home interior ready for move-in",
    description:
      "Start fresh or leave spotless — a thorough top-to-bottom clean for smooth transitions.",
  },
  {
    icon: HardHat,
    title: "Post-Construction Cleaning",
    tag: "Final-stage",
    image: "/images/service-post-construction.jpg",
    alt: "Interior after post-construction cleaning — dust and debris removed",
    description:
      "Remove the dust and debris left behind so your space is truly ready to live or work in.",
  },
  {
    icon: Sparkles,
    title: "Deep Cleaning",
    tag: "Top-to-bottom",
    image: "/images/service-deep.jpg",
    alt: "Close-up detail of a professional deep clean — microfiber cloth on a gleaming surface",
    description:
      "Detailed, comprehensive attention to the spaces and areas that need extra care.",
  },
  {
    icon: CalendarClock,
    title: "Recurring Cleaning",
    tag: "Weekly / Bi-weekly",
    image: "/images/service-recurring.jpg",
    alt: "Bright, freshly maintained living room that conveys a regularly cared-for home",
    description:
      "Set it and forget it — reliable, scheduled cleaning that keeps your space consistently spotless.",
  },
];

export function Services({ showHeading = true }: { showHeading?: boolean } = {}) {
  return (
    <Section id="services" className="bg-cream">
      <Container>
        {showHeading && (
          <SectionHeading
            eyebrow="Our Services"
            title={
              <>
                Cleaning services built around{" "}
                <span className="text-gradient-brand">your standards</span>
              </>
            }
            subtitle="From everyday home upkeep to specialized post-construction and commercial work — every service is delivered with the same attention to detail and personal care."
          />
        )}

        <div className={`${showHeading ? "mt-12" : "mt-0"} grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3`}>
          {SERVICES.map((s, i) => (
            <ServiceCard key={s.title} service={s} index={i} />
          ))}
        </div>

        {/* Customized — full-width CTA banner (7th service) */}
        <CustomizedBanner />
      </Container>
    </Section>
  );
}

function ServiceCard({ service, index }: { service: Service; index: number }) {
  return (
    <motion.article
      initial={{ opacity: 0, y: 18 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.45, delay: (index % 3) * 0.06, ease: "easeOut" }}
      className="group relative flex flex-col overflow-hidden rounded-2xl border border-border/70 bg-card shadow-premium transition-all duration-[320ms] ease-out hover:-translate-y-1.5 hover:border-brand-teal/40 hover:shadow-premium-lg"
    >
      {/* Image with zoom on hover */}
      <div className="relative aspect-[16/10] overflow-hidden">
        <SmartImage
          src={service.image}
          alt={service.alt}
          className="absolute inset-0 size-full object-cover transition-transform duration-[350ms] ease-out group-hover:scale-[1.045]"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-brand-navy/75 via-brand-navy/10 to-transparent opacity-90 transition-opacity duration-300 group-hover:opacity-100" />

        {/* Icon badge */}
        <span className="absolute left-4 top-4 flex size-11 items-center justify-center rounded-xl border border-white/20 bg-brand-navy/55 text-brand-aqua backdrop-blur-md transition-all duration-[320ms] group-hover:scale-110 group-hover:bg-brand-teal group-hover:text-white">
          <service.icon className="size-5" strokeWidth={1.9} />
        </span>
        {/* Tag */}
        <span className="absolute right-4 top-4 rounded-full border border-white/20 bg-background/85 px-2.5 py-1 text-[0.62rem] font-semibold uppercase tracking-wider text-muted-foreground backdrop-blur">
          {service.tag}
        </span>
        {/* Title on image */}
        <h3 className="absolute inset-x-4 bottom-3 font-display text-xl font-bold tracking-tight text-white">
          {service.title}
        </h3>
      </div>

      {/* Body */}
      <div className="flex flex-1 flex-col p-5">
        <p className="text-sm leading-relaxed text-muted-foreground">
          {service.description}
        </p>
        <a
          href="/contact"
          className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-brand-teal transition-all duration-[320ms] group-hover:gap-2.5"
        >
          <CalendarCheck className="size-4" />
          Request this service
          <ArrowRight className="size-4 transition-transform duration-[320ms] group-hover:translate-x-0.5" />
        </a>
      </div>
    </motion.article>
  );
}

function CustomizedBanner() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 18 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      className="group relative mt-5 flex flex-col items-start justify-between overflow-hidden rounded-2xl border border-brand-teal/30 bg-brand-navy p-7 text-white shadow-premium-lg sm:flex-row sm:items-center sm:p-8"
    >
      <div className="pointer-events-none absolute -right-16 -top-16 size-56 rounded-full bg-brand-teal/25 blur-3xl" />
      <div className="pointer-events-none absolute inset-0 bg-grid-light opacity-[0.06]" />
      <div className="relative flex items-start gap-4">
        <span className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-brand-teal/20 text-brand-aqua transition-transform duration-300 group-hover:scale-105">
          <SlidersHorizontal className="size-6" strokeWidth={1.9} />
        </span>
        <div>
          <span className="text-xs font-semibold uppercase tracking-[0.18em] text-brand-aqua">
            Customized Cleaning Services
          </span>
          <h3 className="mt-1.5 font-display text-2xl font-bold leading-tight tracking-tight">
            Have a unique situation? We build a plan around it.
          </h3>
          <p className="mt-2 max-w-xl text-sm leading-relaxed text-white/70">
            Tell us what matters most — personalized checklists, special projects,
            and seasonal tasks, with transparent, itemized pricing.
          </p>
        </div>
      </div>
      <Button
        asChild
        className="relative mt-5 gap-2 bg-brand-teal text-white shadow-teal hover:bg-brand-teal/90 sm:mt-0"
      >
        <a href="/contact">
          <CalendarCheck className="size-4" />
          Get a Free Quote
        </a>
      </Button>
    </motion.div>
  );
}
