import * as React from "react";

/**
 * Static-hosting-friendly image component.
 * Serves WebP to modern browsers (with JPEG fallback) via <picture>,
 * lazy-loads by default, and decodes asynchronously. No runtime/server
 * image optimization required — works on Cloudflare Pages as-is.
 */
export function SmartImage({
  src,
  alt,
  className,
  draggable = true,
  priority = false,
}: {
  src: string;
  alt: string;
  className?: string;
  draggable?: boolean;
  priority?: boolean;
}) {
  const webp = src.replace(/\.(jpe?g|png)$/i, ".webp");
  return (
    <picture>
      <source srcSet={webp} type="image/webp" />
      <img
        src={src}
        alt={alt}
        className={className}
        loading={priority ? "eager" : "lazy"}
        decoding="async"
        draggable={draggable}
      />
    </picture>
  );
}
