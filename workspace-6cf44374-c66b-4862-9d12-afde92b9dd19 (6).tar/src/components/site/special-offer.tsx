"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { CalendarCheck, Clock, Users, Check, Info, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Container, Section, Eyebrow } from "./section-primitives";

const INCLUDED = [
  "Up to 2 professional maids",
  "Standard cleaning supplies & equipment",
  "Kitchens, baths, floors & living areas",
  "Flexible scheduling where available",
];

export function SpecialOffer() {
  return (
    <Section id="offer" className="bg-background py-16 sm:py-20">
      <Container>
        <div className="grid grid-cols-1 overflow-hidden rounded-3xl border border-brand-teal/25 bg-brand-navy shadow-premium-lg lg:grid-cols-12">
          {/* Left — price + label */}
          <div className="relative flex flex-col justify-between gap-6 p-8 sm:p-10 lg:col-span-5">
            <div className="pointer-events-none absolute -right-16 -top-16 size-56 rounded-full bg-brand-teal/25 blur-3xl" />
            <div className="pointer-events-none absolute inset-0 bg-grid-light opacity-[0.07]" />
            <div className="relative">
              <Eyebrow tone="aqua">Special Offer</Eyebrow>
              <p className="mt-5 font-display text-sm font-semibold uppercase tracking-[0.2em] text-white/60">
                Limited-time cleaning package
              </p>
              <div className="mt-2 flex items-end gap-2">
                <span className="font-display text-6xl font-extrabold leading-none text-white sm:text-7xl">
                  $299
                </span>
                <span className="mb-1 text-sm font-medium text-white/55">/ package</span>
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                <span className="inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/5 px-3 py-1.5 text-xs font-semibold text-white/80">
                  <Clock className="size-3.5 text-brand-aqua" /> Up to 4 Hours
                </span>
                <span className="inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/5 px-3 py-1.5 text-xs font-semibold text-white/80">
                  <Users className="size-3.5 text-brand-aqua" /> 2 Professional Maids
                </span>
              </div>
            </div>
            <div className="relative">
              <Button asChild size="lg" className="gap-2 bg-brand-teal text-white shadow-teal hover:bg-brand-teal/90">
                <a href="/contact">
                  <CalendarCheck className="size-4" />
                  Get a Free Quote
                </a>
              </Button>
            </div>
          </div>

          {/* Right — included + note */}
          <div className="flex flex-col justify-center gap-6 border-t border-white/10 bg-white/[0.03] p-8 sm:p-10 lg:col-span-7 lg:border-l lg:border-t-0">
            <div>
              <h3 className="font-display text-2xl font-bold tracking-tight text-white">
                A complete clean for your home
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-white/65">
                A straightforward, all-in cleaning package for Wichita homes —
                no complicated pricing, no surprises.
              </p>
            </div>
            <ul className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {INCLUDED.map((inc, i) => (
                <motion.li
                  key={inc}
                  initial={{ opacity: 0, x: 12 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.35, delay: i * 0.05 }}
                  className="flex items-start gap-2.5 text-sm text-white/85"
                >
                  <span className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-brand-aqua/20 text-brand-aqua">
                    <Check className="size-3.5" strokeWidth={3} />
                  </span>
                  {inc}
                </motion.li>
              ))}
            </ul>
            <div className="flex items-start gap-2.5 rounded-xl border border-white/10 bg-white/[0.03] p-3.5 text-xs leading-relaxed text-white/55">
              <Info className="mt-0.5 size-4 shrink-0 text-brand-aqua/80" />
              <span>
                <span className="font-medium text-white/75">Not included:</span> oven
                and refrigerator cleaning. Add these as part of your personalized
                quote if you&apos;d like them covered.
              </span>
            </div>
            <a
              href="/contact"
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-brand-aqua hover:underline"
            >
              See if this package fits your home
              <ArrowRight className="size-4" />
            </a>
          </div>
        </div>
      </Container>
    </Section>
  );
}
