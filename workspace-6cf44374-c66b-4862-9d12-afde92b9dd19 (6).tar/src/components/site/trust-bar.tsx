"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { CalendarCheck, ShieldCheck, Users, MapPin } from "lucide-react";
import { Container } from "./section-primitives";

const ITEMS = [
  { icon: CalendarCheck, stat: "2008", label: "Serving Wichita since", sub: "17+ years of local experience" },
  { icon: ShieldCheck, stat: "Insured", label: "& background-checked", sub: "Professional, vetted staff" },
  { icon: Users, stat: "Family", label: "-owned & operated", sub: "Local Wichita business" },
  { icon: MapPin, stat: "Wichita", label: "& surrounding areas", sub: "Maize, Andover, Derby & more" },
];

export function TrustBar() {
  return (
    <section className="relative z-10 -mt-10 px-0 pb-2">
      <Container>
        {/* Mobile / tablet — premium vertical connected timeline */}
        <div className="overflow-hidden rounded-2xl border border-border/70 bg-card p-5 shadow-premium sm:p-6 lg:hidden">
          <ol className="relative pl-7">
            {/* connecting line */}
            <span
              aria-hidden
              className="absolute left-[18px] top-2 bottom-2 w-px bg-gradient-to-b from-brand-teal/45 via-brand-teal/25 to-transparent"
            />
            {ITEMS.map((item, i) => (
              <motion.li
                key={item.label}
                initial={{ opacity: 0, x: 10 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, margin: "-30px" }}
                transition={{ duration: 0.35, delay: i * 0.06 }}
                className="relative flex items-start gap-3.5 pb-4 last:pb-0"
              >
                <span className="relative z-10 mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-full border border-brand-teal/30 bg-card text-brand-teal shadow-premium">
                  <item.icon className="size-4" strokeWidth={2.1} />
                </span>
                <div className="min-w-0 pt-0.5">
                  <div className="text-sm leading-snug">
                    <span className="font-display text-base font-bold text-brand-navy">
                      {item.stat}
                    </span>
                    <span className="font-medium text-foreground/80"> {item.label}</span>
                  </div>
                  <div className="mt-0.5 text-xs text-muted-foreground">{item.sub}</div>
                </div>
              </motion.li>
            ))}
          </ol>
        </div>

        {/* Desktop — 4-column grid */}
        <div className="hidden overflow-hidden rounded-2xl border border-border/70 bg-card shadow-premium-lg lg:grid lg:grid-cols-4">
          {ITEMS.map((item, i) => (
            <div
              key={item.label}
              className={
                "flex items-center gap-4 p-6 " +
                (i < ITEMS.length - 1 ? "border-r border-border/70 " : "")
              }
            >
              <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-brand-teal/10 text-brand-teal">
                <item.icon className="size-5" strokeWidth={2.1} />
              </span>
              <div className="min-w-0">
                <div className="font-display text-xl font-bold leading-none tracking-tight text-foreground">
                  {item.stat}
                </div>
                <div className="mt-1 text-sm font-medium text-foreground/80">{item.label}</div>
                <div className="mt-0.5 text-xs text-muted-foreground">{item.sub}</div>
              </div>
            </div>
          ))}
        </div>
      </Container>
    </section>
  );
}
