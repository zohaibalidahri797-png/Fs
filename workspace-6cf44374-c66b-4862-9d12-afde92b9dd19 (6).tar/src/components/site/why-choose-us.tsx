"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Award, BadgeCheck, ShieldCheck, SprayCan, Zap, ScanSearch, Sparkles } from "lucide-react";
import { Container, Section, Eyebrow } from "./section-primitives";
import { SmartImage } from "./smart-image";

const BENEFITS = [
  {
    icon: Award,
    title: "Experienced staff",
    text: "Trained cleaning professionals with years of hands-on Wichita service.",
  },
  {
    icon: BadgeCheck,
    title: "Background-checked",
    text: "Every team member is vetted for your peace of mind.",
  },
  {
    icon: ShieldCheck,
    title: "Insured service",
    text: "Fully insured cleaning on every visit, homes and businesses alike.",
  },
  {
    icon: SprayCan,
    title: "Professional supplies & equipment",
    text: "Pro-grade products and equipment for a thorough, lasting clean.",
  },
  {
    icon: Zap,
    title: "Same-day availability",
    text: "Same-day service when the schedule allows, for time-sensitive needs.",
  },
  {
    icon: ScanSearch,
    title: "Attention to detail",
    text: "Corners, edges, and the small things that show — every time.",
  },
];

export function WhyChooseUs() {
  return (
    <Section id="why-us" className="bg-background">
      <Container>
        <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-2 lg:gap-16">
          {/* Left — large visual */}
          <div className="relative order-2 lg:order-1">
            <div className="relative overflow-hidden rounded-3xl border border-border/70 shadow-premium-lg">
              <SmartImage
                src="/images/residential-home.jpg"
                alt="Spotless, sunlit Wichita home interior — the standard Wichita Maid Service delivers"
                className="aspect-[4/5] w-full object-cover sm:aspect-[5/4] lg:aspect-[4/5]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-brand-navy/55 via-transparent to-transparent" />
            </div>

            {/* Overlapping statement card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="absolute -right-3 bottom-6 w-[230px] rounded-2xl border border-border/70 bg-card p-5 shadow-premium-lg sm:-right-6"
            >
              <span className="flex size-10 items-center justify-center rounded-xl bg-brand-teal/10 text-brand-teal">
                <Sparkles className="size-5" />
              </span>
              <p className="mt-3 font-display text-lg font-bold leading-tight tracking-tight text-foreground">
                &ldquo;Local. Family-owned. Since 2008.&rdquo;
              </p>
              <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                Built on relationships, not transactions.
              </p>
            </motion.div>
          </div>

          {/* Right — statement + benefits */}
          <div className="order-1 lg:order-2">
            <Eyebrow>Why Choose Us</Eyebrow>
            <h2 className="mt-4 font-display text-3xl font-bold leading-[1.1] tracking-tight sm:text-4xl">
              Trusted for the right reasons —
              <br className="hidden sm:block" /> and the{" "}
              <span className="text-gradient-brand">details</span>.
            </h2>
            <p className="mt-4 max-w-lg text-base leading-relaxed text-muted-foreground">
              We&apos;re a local family business, not a faceless chain. That means
              personal accountability, consistent quality, and a real relationship
              with the people we clean for — backed by the professionalism you
              expect from an established company.
            </p>

            <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2">
              {BENEFITS.map((b, i) => (
                <motion.div
                  key={b.title}
                  initial={{ opacity: 0, y: 14 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-40px" }}
                  transition={{ duration: 0.4, delay: (i % 2) * 0.06 }}
                  className="group relative flex gap-4 overflow-hidden rounded-xl border border-border/60 bg-card p-4 transition-all duration-[320ms] ease-out hover:-translate-y-1 hover:border-brand-teal/40 hover:shadow-premium"
                >
                  <span className="absolute inset-x-0 top-0 h-0.5 origin-left scale-x-0 bg-gradient-to-r from-brand-teal to-brand-aqua transition-transform duration-[320ms] ease-out group-hover:scale-x-100" />
                  <span className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-brand-teal/10 text-brand-teal transition-all duration-[320ms] group-hover:scale-110 group-hover:bg-brand-teal group-hover:text-white">
                    <b.icon className="size-5" strokeWidth={2} />
                  </span>
                  <div>
                    <h3 className="text-sm font-bold leading-snug text-foreground">
                      {b.title}
                    </h3>
                    <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                      {b.text}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </Container>
    </Section>
  );
}
