# Worklog — Wichita Maid Service® Website

Project: Premium residential & commercial cleaning service website for
Wichita Maid Service® | Clean Maid USA LLC (Wichita, Kansas).

Business facts:
- Phone: (316) 477-0101
- Website: cleanmaidusa.com
- Founded: 2008 (17+ years local experience)
- Family-owned, local Wichita business

Design direction:
- Premium, polished, clean, trustworthy, modern, welcoming.
- Palette: deep teal-green primary + warm cream neutrals + warm gold accents.
  (Avoids indigo/blue per global styling rules.)
- Display font: Fraunces (editorial premium feel) for headlines; Geist Sans for body/UI.
- Single route `/` (src/app/page.tsx).

Sections planned (all on homepage):
1. Hero (parallax-on-cursor image, dual CTA)
2. Trust bar (quick stats / credentials)
3. Services (7 service cards with hover-lift reveal)
4. Why Choose Us (strengths grid)
5. For Homes & Businesses (residential/commercial toggle with imagery swap)
6. Before/After reveal slider
7. Service Area (Wichita + surrounding areas, hover glow)
8. About the Company (family business story)
9. Reviews / Testimonials (expandable cards, real-feedback themes only — no fake names/ratings invented)
10. Free Quote (multi-field conversion form → API + DB)
11. Footer (sticky to bottom)

---
Task ID: 1
Agent: main (orchestrator)
Task: Set up design system, Prisma schema, and initialize worklog.

Work Log:
- Read existing scaffold (layout, globals.css, ui components, prisma schema, tailwind config).
- Designed premium emerald-teal + warm cream palette in oklch.
- Selected Fraunces as display font for premium headlines.

Stage Summary:
- About to write globals.css design tokens, layout.tsx (metadata + fonts),
  prisma schema (QuoteRequest model), then launch image-generation subagent
  (Task 3) in parallel while building the page (Task 4).

---
Task ID: 3
Agent: image-generation subagent
Task: Generate 6 premium photographic website images via z-ai-web-dev-sdk.

Work Log:
- Read worklog.md to align with brand palette (teal-green + warm cream + gold, no blue/indigo).
- Invoked `Skill(command="image-generation")` and read its SKILL.md to learn usage.
- Wrote `/home/z/my-project/scripts/gen-images.ts` using the backend SDK
  (`z-ai-web-dev-sdk`) per skill rules (no client-side usage).
- Configured 6 image jobs with tailored prompts:
  1. hero-cleaning.jpg        — 1344x768 landscape, bright home + cleaner
  2. residential-home.jpg    — 864x1152 portrait, sunlit clean living room
  3. commercial-office.jpg   — 1152x864 landscape, spotless office
  4. before-messy.jpg        — 1152x864 landscape, realistically cluttered room
  5. after-clean.jpg         — 1152x864 landscape, same room spotless
  6. about-team.jpg          — 1152x864 landscape, friendly local team
- All prompts explicitly forbid blue/indigo tones and request warm cream +
  sage-green palette with premium real-estate photography style.
- First run: 5/6 succeeded; hero failed because the SKILL.md-documented
  `1440x720` size is actually rejected by the live API (Chinese error:
  "size的长宽均需满足512px-2880px之间,且为32整数倍...") — 720 is NOT a
  multiple of 32. Valid landscape sizes are 1344x768 / 1152x864.
- Wrote one-off `/home/z/my-project/scripts/gen-hero.ts` with size `1344x768`
  to regenerate just the hero; succeeded on attempt 1.
- Verified all 6 files via `ls -la` + `file`:
  All are valid JPEG image data (the SDK actually returns JPEG bytes, not
  PNG as the skill doc implied), correct dimensions, non-empty.

Stage Summary:
- All 6 images successfully saved to `/home/z/my-project/public/images/`:
    hero-cleaning.jpg     ~111 KB  1344x768
    residential-home.jpg  ~145 KB  864x1152
    commercial-office.jpg ~122 KB  1152x864
    before-messy.jpg      ~110 KB  1152x864
    after-clean.jpg       ~122 KB  1152x864
    about-team.jpg        ~116 KB  1152x864
- Method used: backend z-ai-web-dev-sdk via `bun run scripts/*.ts`.
- Scripts left in place at /home/z/my-project/scripts/ for reproducibility.
- Image generation sub-task COMPLETE; page build (Task 4) can now reference
  these paths: /images/hero-cleaning.jpg, /images/residential-home.jpg,
  /images/commercial-office.jpg, /images/before-messy.jpg,
  /images/after-clean.jpg, /images/about-team.jpg.

---
Task ID: 4
Agent: main (orchestrator)
Task: Build the full homepage (page.tsx + section components + API route).

Work Log:
- Created src/components/site/ with: section-primitives, logo, header, hero,
  trust-bar, services, why-choose-us, audiences, before-after, service-area,
  about, testimonials, quote-form, footer.
- page.tsx composes all sections inside a flex min-h-screen flex-col wrapper
  (footer mt-auto -> sticky-to-bottom behavior).
- API: src/app/api/quote/route.ts -> POST validates + persists QuoteRequest
  via Prisma; GET returns endpoint info.
- Fixed a JSX typo ({...props> -> {...props}) caught by lint.
- Removed stray `priority` attr on motion.img (plain img, not next/image).
- Made hero parallax attach regardless of pointer:fine (guarded only by
  prefers-reduced-motion) so it works on any desktop & is verifiable.

Stage Summary:
- All sections render (verified via agent-browser snapshot + VLM).
- Interactions verified end-to-end: hero parallax responds to cursor
  (translateX/Y applied), audiences toggle swaps content+image, before/after
  slider drags (clipPath changes), testimonial cards expand (text 141->345
  chars), mobile hamburger menu opens/closes, mobile footer at bottom.
- Quote form: full 2-step flow works -> POST /api/quote 201 -> record saved
  to SQLite (QuoteRequest) -> slide-in success confirmation.
- Lint clean. No console/runtime errors.

---
Task ID: 6
Agent: main (orchestrator)
Task: Self-verification with agent-browser + VLM.

Work Log:
- agent-browser open http://localhost:3000/ -> title correct, GET 200.
- snapshot -c/-i: confirmed header nav, hero H1 + CTAs, trust bar stats,
  7 service cards + CTA tile, why-choose-us strengths, audiences toggle,
  before/after slider, service area (map iframe + location chips), about,
  testimonials, quote form, footer.
- Tested interactions: audiences toggle (homes->businesses content swap),
  before/after drag (clipPath 45.5%), testimonial expand (button -> Show less),
  quote form (radix selects -> Continue -> step 2 -> submit -> success),
  mobile menu open/close, hero parallax (transform -> translateX(12px)...).
- VLM (z-ai vision) on hero + full-page screenshots: "premium and polished...
  high-end conversion-focused landing page", consistent teal/cream/gold palette,
  footer at bottom, no broken layouts.
- Verified DB record persisted.

Stage Summary:
- Website is interactive, runnable, and visually premium. Task complete.

---
Task ID: 2-redesign
Agent: image-generation subagent (Task 2-redesign)
Task: Generate 2 premium photographic service images (move-in/out, post-construction) via z-ai-web-dev-sdk.

Work Log:
- Read worklog.md to align with brand palette (deep teal-green + warm cream + gold; avoid blue/indigo).
- Invoked `Skill(command="image-generation")` and read its SKILL.md to confirm backend-only usage, supported sizes, and JPEG output.
- Reviewed prior scripts (gen-images.ts, gen-hero.ts) for reference patterns and the API quirks (size must be a multiple of 32 between 512-2880; 720 is invalid).
- Wrote `/home/z/my-project/scripts/gen-service-images.ts`:
  - Uses backend `z-ai-web-dev-sdk` (Bun runtime).
  - Size = `1152x864` (valid landscape, 1152%32==0, 864%32==0).
  - 2 jobs defined with tailored, premium real-estate photography prompts.
  - Each prompt explicitly forbids blue/indigo dominance, forbids people,
    forbids cartoon styling; requests warm cream + sage-green palette,
    soft natural daylight, editorial quality.
  - Retry-up-to-3 logic per image with exponential backoff.
  - Writes raw JPEG bytes (Buffer.from(b64, 'base64')) directly to the
    target file paths.
- Ran `bun run scripts/gen-service-images.ts`. BOTH images succeeded on
  attempt 1 (no retries needed).
- Verified both files via `ls -la` + `file`:
    service-move-in-out.jpg        84930 bytes   JPEG 1152x864
    service-post-construction.jpg  121645 bytes  JPEG 1152x864
  Both are valid JPEG image data, correct dimensions, non-empty.

Stage Summary:
- 2 images successfully saved to `/home/z/my-project/public/images/`:
    service-move-in-out.jpg         ~83 KB  1152x864 (move-in/move-out empty home)
    service-post-construction.jpg  ~119 KB  1152x864 (post-construction cleaned interior)
- Method used: backend z-ai-web-dev-sdk via `bun run scripts/gen-service-images.ts`.
- Script left in place at /home/z/my-project/scripts/gen-service-images.ts
  for reproducibility.
- No failures; no retries required.
- Image generation sub-task COMPLETE; page build can now reference these
  paths: /images/service-move-in-out.jpg, /images/service-post-construction.jpg
  (likely for the "Specialty Cleaning" service cards or a move-in/out +
  post-construction service section).

---
Task ID: redesign (1–16)
Agent: main (orchestrator)
Task: Full PRD-driven redesign & visual experience upgrade of the existing
Wichita Maid Service website (premium modern trustworthy conversion-focused).

Work Log:
- NEW design system: Deep Navy primary + Professional Teal secondary + Subtle
  Aqua accent + warm-white/very-light-mist backgrounds (globals.css).
- NEW typography: Plus Jakarta Sans (display) + Inter (body). Removed Fraunces.
- layout.tsx: enhanced metadata (canonical, OG, Twitter, robots), JSON-LD
  LocalBusiness schema (address 1020 E English St, phone, founded 2008,
  areaServed) — NO fake reviews/rating in schema.
- SEO: public/sitemap.xml (homepage), updated public/robots.txt.
- Rebuilt Header: Home/Services/About/Reviews/FAQ/Contact, premium sticky,
  scroll-aware, mobile full-width drawer, phone icon on mobile. No sidebar.
- Rebuilt Hero: 5-layer depth system (atmosphere + large image + foreground
  depth cards + floating trust + CTAs), CSS perspective, scroll + mouse
  parallax (subtle, reduced-motion respected), mobile-optimized height
  (min-h-[92svh], compact). Primary GET A FREE QUOTE / secondary CALL NOW.
- NEW MobileCtaBar: fixed bottom CALL NOW + GET QUOTE, safe-area inset,
  dismissible, auto-hides when #quote is in view (never covers form fields).
- NEW SpecialOffer ($299 / up to 4 hrs / 2 maids; oven+fridge NOT included;
  no fake countdown/urgency).
- Rebuilt Services as interactive selector: 4 services, desktop split
  (left list / right image+content), mobile pill selector + stacked content,
  smooth AnimatePresence transitions. Added 2 new images (move-in/out,
  post-construction).
- Rebuilt WhyChooseUs: editorial asymmetric (large image + overlapping
  statement card + 6 benefits, not 8 identical cards).
- Refined Before/After slider (palette + new handle styling, touch+mouse).
- NEW HowItWorks: 4-step (Request Quote / Discuss / Schedule / Enjoy),
  horizontal desktop flow, vertical mobile timeline.
- Rebuilt About: editorial split, left image, "Established 2008" badge,
  LOCAL. EXPERIENCED. PROFESSIONAL. narrative + 4 pillars.
- Rebuilt ServiceArea: map + highlights + verified address
  (1020 E English St, Suite A1, Wichita, KS 67211) + OPEN IN GOOGLE MAPS
  (Google Maps embed, no API key). Refined area chips (no giant keyword grid).
- REPLACED Reviews: dark premium "Customer Feedback" section, heading
  "Trusted by Wichita home & business owners", READ OUR GOOGLE REVIEWS CTA,
  "Real feedback. No fabricated testimonials." statement. ZERO empty review
  cards, ZERO "Review Slot" text, no fake names/ratings.
- NEW Commitment: short full-bleed band, "A Cleaner Space. More Time for What
  Matters." + one strong image.
- NEW FAQ: premium accordion (2-col layout: heading/contact card + accordion),
  10 honest Q&As.
- NEW FinalCta: dark conversion band (Get a Free Quote + Call).
- Rebuilt QuoteForm: full field set (Name/Phone/Email/Service/Property Type/
  Preferred Date/Preferred Time/Property Size/Message), single-page 2-col
  grid, full-width mobile, large touch targets, validation, slide-in success.
- API route rewritten: removed Prisma/database dependency — validation-only,
  logs submission, returns 201. Static-hosting friendly (production can wire
  to a form provider).
- Rebuilt Footer: dark navy, logo(onDark), full contact incl. verified address
  + hours, services/areas/company columns, sticky-to-bottom (mt-auto wrapper).

Verification (agent-browser + VLM):
- Page GET / 200, correct title, no console errors.
- "Review Slot" source + rendered search = ZERO. "reserved" only appears in
  footer "All rights reserved" (legitimate).
- Service selector swaps title + image. FAQ accordion expands (answer visible).
  Quote form full flow works -> POST /api/quote 201 -> success state.
- Horizontal overflow = 0px at 320/375/390/414/768/1024/1280/1440 (all).
- Mobile CTA bar visible on mobile (Call Now + Get Quote), hides over quote form.
- VLM (hero): premium layered depth, navy+teal+aqua (not generic blue),
  clear headline + both CTAs, communicates Wichita since 2008.
- VLM (reviews): dark premium, Google reviews CTA, NO empty cards,
  complete/intentional, "no fabricated testimonials" statement present.
- VLM (mobile hero): compact, headline + CTA above fold, no overflow, premium.
- VLM (full page): agency-quality, varied layouts (not heading+3-cards
  repeated), no placeholders, trustworthy, premium. "Looks like a professional
  agency built it."

Stage Summary:
- Full PRD implemented on the single / route (sandbox restricts to /; nav is
  anchor-based, satisfying "working navigation"). Marketing pages render with
  no DB/server dependency. All acceptance criteria (Reviews/Hero/Services/
  Animation/Mobile/SEO/Technical) verified true.

---
Task ID: polish-pass
Agent: main (orchestrator)
Task: Master client-demo polish pass — remove placeholders (none found in
current build), add verified email, remove invented business hours, add 404,
elevate before/after to case-study, tighten mobile hero, WebP image optimization.

Work Log:
- Audited source for placeholders: ZERO "Review Slot"/"reserved"(except footer
  "All rights reserved")/"coming soon"/"lorem" in content. Reviews section
  already replaced (Google Reviews CTA, no empty cards) in prior redesign.
- CORRECTION per "do not invent business hours": removed invented "Mon–Fri 8–6,
  Sat 9–4" from footer + service-area address card + removed
  openingHoursSpecification from JSON-LD LocalBusiness schema.
- Added verified email CleanMaidUS@gmail.com to: footer contact, service-area
  address card, quote-form contact column, and JSON-LD `email` field.
- Added premium on-brand 404 page (src/app/not-found.tsx) with Header/Footer/
  MobileCtaBar; verified /missing-route renders 404 + Back to home + call CTA.
- Performance: generated .webp for all 8 images via sharp (30–49% smaller);
  created SmartImage component (<picture> webp+jpg fallback, lazy, async decode,
  static-hosting friendly); swapped content images in services/about/
  why-choose-us/commitment/before-after to SmartImage. Hero motion.img given
  fetchPriority="high" for LCP. (Hero + before/after kept as plain img where
  transform/clip control needed; before/after now uses SmartImage.)
- Elevated Before/After into a case-study experience: new "This is the result
  we create" framing, glow ring on the drag handle, camera-icon honest note
  "Illustrative example ... not a specific client project."
- Tightened mobile hero: smaller H1 on mobile (2.05rem), shorter paragraph,
  reduced vertical spacing; removed redundant mobile trust box (trust badges
  row already conveys trust). CTA now ~65% down viewport (was ~74%), firmly
  above the fold at 320/375/390/414. Floating depth cards remain desktop-only.

Verification (agent-browser + VLM):
- 404 page renders (has404 + Back to home) ✓
- Home DOM: email present, invented hours GONE, reviewSlot = 0 ✓
- Horizontal overflow = 0px at 320/375/390/414/768/1024/1280/1440 ✓
- Hero CTA above fold at 320/390/414 (pctDown 66/65/65) ✓
- Floating cards hidden on mobile (0 visible) ✓
- Before/After slider drag works (clip 52%→47.8%), glow + illustrative note ✓
- No console errors; GET / 200; lint clean.
- VLM mobile hero: CTA visible without scrolling, compact, no overlapping cards,
  communicates Wichita since 2008, premium ✓
- VLM full page (prior): no empty review boxes, no fake testimonials, premium
  agency feel, varied layouts, trustworthy, complete ✓

Stage Summary:
- All PRD polish items addressed on the existing project without rebuilding or
  removing good content. Verified business info preserved/expanded (email added,
  invented hours removed). 404 + WebP + mobile hero tightening delivered. Site
  remains single-route (sandbox constraint), static-hosting friendly (no Prisma/
  DB/server/secret for rendering), SEO intact (canonical/OG/Twitter/sitemap/
  robots/LocalBusiness schema with no fake review schema).

---
Task ID: 2-hero3d
Agent: image-generation subagent (Task 2-hero3d)
Task: Generate 2 premium photographic service images (deep clean detail + recurring maintenance living room) via z-ai-web-dev-sdk.

Work Log:
- Read worklog.md to align with current brand palette (deep navy + professional teal + warm white + subtle aqua; avoid blue/indigo dominance; no cartoon/3D-people).
- Invoked `Skill(command="image-generation")` and read its SKILL.md to confirm backend-only usage, supported sizes, and JPEG output.
- Reviewed prior scripts (gen-service-images.ts, gen-hero.ts) for reference patterns and known API quirks (size must be a multiple of 32 between 512-2880; 1440x720 is invalid because 720 is not a multiple of 32).
- Wrote `/home/z/my-project/scripts/gen-deep-recurring.ts`:
  - Uses backend `z-ai-web-dev-sdk` (Bun runtime).
  - Size = `1152x864` (valid landscape: 1152%32==0, 864%32==0).
  - 2 jobs defined with tailored, premium real-estate photography prompts.
  - Each prompt explicitly forbids blue/indigo dominance, forbids faces/people,
    forbids cartoon / 3D-people styling; requests warm cream + navy + teal +
    sage-green palette, soft natural daylight, editorial quality.
  - Retry-up-to-2-times-then-move-on logic per image (initial + 2 retries = 3
    attempts max) with exponential backoff.
  - Writes raw JPEG bytes (Buffer.from(b64, 'base64')) directly to the target
    file paths.
- Ran `bun run scripts/gen-deep-recurring.ts`. BOTH images succeeded on
  attempt 1 (no retries needed).
- Verified both files via `ls -la` + `file`:
    service-deep.jpg       88979 bytes   JPEG 1152x864 (gloved hand detailing gleaming faucet/surface)
    service-recurring.jpg 131251 bytes  JPEG 1152x864 (tidy lived-in Wichita living room, plump sofa + plant)
  Both are valid JPEG image data, correct dimensions, non-empty.

Stage Summary:
- 2 images successfully saved to `/home/z/my-project/public/images/`:
    service-deep.jpg        ~87 KB   1152x864 (close-up deep-clean detail, gloved hand + microfiber cloth + sparkling chrome/stone)
    service-recurring.jpg  ~128 KB   1152x864 (weekly-care lived-in-but-tidy living room, plump sofa + neat coffee table + small plant)
- Method used: backend z-ai-web-dev-sdk via `bun run scripts/gen-deep-recurring.ts`.
- Script left in place at /home/z/my-project/scripts/gen-deep-recurring.ts for
  reproducibility.
- No failures; no retries required.
- Image generation sub-task COMPLETE; page build can now reference these
  paths: /images/service-deep.jpg, /images/service-recurring.jpg (likely for
  the "Deep Clean" and "Recurring Cleaning" service cards in the interactive
  service selector).

---
Task ID: enhancement-3d
Agent: main (orchestrator)
Task: Enhancement pass — premium 3D/depth hero, 7-card services, multi-step
quote form, interactive Why-Choose-Us, animated map marker, header nav,
mobile CTA entrance. Preserved all existing content/SEO/forms/images.

Work Log:
- Header: added "Why Choose Us" nav link (#why-us) to desktop nav + mobile
  drawer (nav now Home/Services/Why Choose Us/About/Reviews/FAQ/Contact).
- Hero: rebuilt into a true 6-layer depth system with DISTINCT parallax motion
  values per layer (bg slow → seal → chip1 → chip2 → chip3 → spray → sparkles
  independent), plus scroll parallax (floatScrollY drifts foreground up
  opposite the bg). 4 meaningful glass trust cards (2008 "17+ yrs in Wichita"
  seal, Insured, Background-Checked, Family-Owned) + SprayCan cleaning-object
  accent + 3 sparkle particles. Mobile: lightweight sparkle dots with gentle
  float (no cursor). Sequential entrance animations. prefers-reduced-motion
  respected (parallax off).
- Generated 2 new images (service-deep.jpg, service-recurring.jpg) + WebP
  (35-39% smaller) via sharp.
- Services: converted the 4-item interactive selector into a premium 7-card
  grid — 6 image cards (Residential/Commercial/Move-In-Out/Post-Construction/
  Deep/Recurring) + full-width Customized Cleaning CTA banner. Each card:
  SmartImage (webp) with hover zoom scale-[1.045], icon badge animates +
  color-shifts on hover, gradient overlay, "Request this service" CTA with
  arrow slide. 320ms transitions.
- Why Choose Us: benefits now interactive cards — hover lift + top accent
  line reveal + icon scale+color shift (teal fill).
- Service Area: added animated pulsing location marker (ping ring + MapPin +
  "Wichita, KS" label) overlay on the map for an integrated feel.
- Quote form: rebuilt as MULTI-STEP (Service → Property → Schedule → Contact)
  with a progress bar (% + segmented fill), per-step validation, smooth
  x-slide transitions between steps, Back/Continue, Submit on final step,
  slide-in success + error states. All 9 fields preserved.
- Mobile CTA bar: smooth slide-up entrance (framer-motion + AnimatePresence),
  exit on dismiss/hide, safe-area inset, hides over #quote.

Verification (agent-browser + VLM):
- Lint clean; GET / 200; no console errors.
- Nav has "Why Choose Us" ✓; 6 service cards + Customized banner ✓; form
  "Step X of 4" progress ✓ (CSS-uppercased); reviewSlot = 0 ✓.
- Responsive QA at 320x640/375x812/390x844/414x896/768x1024/1024x768/
  1280x800/1440x900: overflow = 0px at ALL; hero CTA above fold at ALL;
  floating cards below header (no overlap) at ALL.
- Hero parallax: floating cards respond to cursor at DISTINCT depths
  (chip2 -16.9px, chip1 -13px, chip3 -7.2px) → real layered depth, not a zoom.
- Multi-step form flow: Step1 Recurring→Continue→Step2 Single-family→
  Continue→Step3 (skip optional)→Continue→Step4 contact→Submit→POST
  /api/quote 201→success ✓.
- VLM hero: "premium layered 3D depth… multiple floating glass trust cards
  at varying depths + sparkles… meaningful content not placeholder boxes…
  deep navy + teal + aqua… not a flat template" ✓.
- VLM services: "premium cards with image+icon+name+desc+CTA… not generic
  stock placeholders" ✓.
- VLM mobile hero: "CTA visible without scrolling… subtle lightweight floating
  depth without clutter… no overflow… premium" ✓.

Stage Summary:
- Existing site enhanced into a richer premium 3D/interactive experience
  WITHOUT rebuilding or removing content. All verified business info, SEO,
  images, forms, API, sitemap, robots, JSON-LD preserved. Added 2 images +
  webp. 6-layer hero depth, 7-card services, multi-step quote form, animated
  map marker, interactive benefits, mobile CTA entrance. Fast (CSS transforms +
  framer-motion, lazy webp images, reduced-motion supported), responsive at all
  8 PRD breakpoints, no overflow/overlap, no console errors.

---
Task ID: fix-upgrade-3d
Agent: main (orchestrator)
Task: Fix & upgrade pass — header tablet nav, genuine 3D perspective tilt hero,
preserve all existing content/SEO/forms/images. Targeted improvements only.

Work Log:
- Header: lowered nav/CTA breakpoint from xl(1280) to lg(1024) so tablet
  widths (1024) now show the full desktop nav (Home/Services/Why Choose Us/
  About/Reviews/FAQ/Contact + Get a Free Quote), phone link shows at xl,
  mobile menu (hamburger) below 1024. Compact nav padding at lg (px-2.5,
  px-3.5 at xl). Removed stray onClick no-op on drawer CTA. Premium glass
  sticky header preserved (no overlap with hero).
- Hero — GENUINE 3D (not just 2D parallax):
  * Added 3D perspective TILT: tiltX/tiltY motion values (rotateX ±3.5deg,
    rotateY ±4deg, derived from spring-smoothed mouse coords) applied to the
    floating-composition container with transformStyle: preserve-3d.
  * Added perspective:1000 on the composition's direct parent (grid div) so
    the rotate renders in true 3D space (not flattened by intermediate
    non-preserve-3d ancestors).
  * Added translateZ (z) depth per layer so cards spatially separate during
    tilt: seal z40, Insured z80, Background-Checked z110, Family-Owned z60,
    SprayCan accent z140, sparkles z170.
  * Kept per-layer x/y mouse parallax (different speeds) + scroll parallax
    (floatScrollY) + sparkle float. Reduced-motion respected (parallax off).
  * Mobile: lightweight sparkle float + bg scroll parallax (no cursor).
- No other sections changed (services 7-card grid, before/after, why-choose-us
  interactive cards, service-area animated marker, reviews Google CTA, multi-
  step quote form, mobile CTA, SEO/sitemap/robots/JSON-LD all preserved).

Verification (agent-browser + VLM):
- Lint clean; GET / 200; no console errors.
- Header responsive: navVisible at >=1024, mobileMenu at <1024; mobile drawer
  opens with all 7 nav links + closes after select. overflow=0 at every width.
- Responsive QA at 320/375/390/414/768/820/1024/1280/1440: overflow=0 at ALL;
  hero CTA above fold at ALL.
- 3D hero DOM-verified: composition transform = rotateX(-1.17deg)
  rotateY(2.11deg) on mousemove (engages); cards render translateZ(80/110/60px)
  -> real spatial separation during tilt.
- VLM hero (prose): "layered 3D depth with floating glass trust cards at
  varying depths... cards distinctly separated from the background, enhanced by
  the active 3D tilt... premium and sophisticated, not a flat template."
- VLM mobile: "CTA visible without scrolling... subtle floating depth without
  clutter... Wichita since 2008... no horizontal overflow."

Stage Summary:
- Focused fix + upgrade: header now usable at tablet; hero transformed from
  flat 2D-parallax into a genuine 3D perspective-tilt layered composition
  (rotateX/rotateY + translateZ depth per layer). All existing content, SEO,
  forms, images, and components preserved. Fast (CSS transforms + framer-motion,
  reduced-motion supported), responsive at all PRD breakpoints, no overflow,
  no console errors.

---
Task ID: final-production
Agent: main (orchestrator)
Task: FINAL production pass — proper multi-page architecture, re-add Homes/Businesses,
FAQ schema, consistent multi-page CTAs, sitemap. Preserved all existing content/SEO/
forms/images/hero-3D.

Work Log:
- Confirmed Caddyfile proxies ALL paths to localhost:3000 -> Next.js routes are
  reachable through the gateway. (Homepage stays fully intact.)
- Created dedicated routes (each server component w/ unique metadata: title,
  description, canonical, OpenGraph; title uses layout template):
    /services  -> PageHero + <Services/> + PageCta
    /about     -> PageHero + <About/> + <Commitment/> + PageCta
    /contact   -> PageHero + <QuoteForm/>
    /reviews   -> PageHero + <Reviews/> + PageCta
    /faq       -> PageHero + <Faq/> + PageCta + FAQPage JSON-LD
    /privacy-policy, /terms, /disclaimer -> PageHero + honest legal prose + PageCta
  (404 already existed as not-found.tsx.)
- New shared components: page-shell.tsx (PageLayout + PageHero + PageCta),
  legal.tsx (LegalContent), faq-data.ts (shared FAQ data for DRY schema).
- Re-added Audiences (Homes vs Businesses toggle) to homepage between WhyChooseUs
  and BeforeAfter; rebuilt with current navy/teal/aqua palette + SmartImage.
- Header nav -> page links (Home /, Services /services, Why Choose Us /#why-us,
  About /about, Reviews /reviews, FAQ /faq, Contact /contact); CTA -> /contact;
  logo -> /. Mobile drawer links to pages, closes after select, locks bg scroll.
- Footer -> page links + legal row (Privacy Policy / Terms / Disclaimer) +
  "Back to home"; added mobile bottom padding (pb-28) so sticky CTA bar never
  covers footer content.
- Routed all shared-section CTAs to /contact (consistent across pages); hero CTA
  stays #quote (homepage in-page, primary). Mobile CTA "Get Quote" -> /contact.
- SEO: per-page unique title/description/canonical/OG; FAQPage JSON-LD on /faq
  (verified in HTML: FAQPage/Question/Answer); LocalBusiness JSON-LD site-wide;
  updated sitemap.xml with all 9 routes; robots.txt unchanged (sitemap ref).
- Deployment: quote API remains Prisma-free (validation-only, no DB) -> static-
  hosting friendly; marketing pages render with no server/DB dependency.

Verification (agent-browser + curl):
- HTTP: / /services /about /contact /reviews /faq /privacy-policy /terms
  /disclaimer all -> 200; /nonexistent -> 404.
- Lint clean; no console errors.
- Homepage structure complete (Hero/Trust/Offer/Services[7]/WhyChooseUs/Audiences/
  BeforeAfter/HowItWorks/About/ServiceArea/Reviews/Commitment/Faq/FinalCta/Quote).
- Nav click "Services" -> /services (H1 "Professional cleaning services in Wichita,
  KS", breadcrumb, PageCta). Mobile menu "About" -> /about (closes menu, navigates).
- FAQ schema present in /faq HTML (FAQPage/Question/Answer via curl).
- Responsive overflow = 0px at 320/375/390/414/768/820/1024/1280/1440/1920
  (homepage) + 390/1440 (/services).
- VLM homepage: "premium layered 3D hero with floating glass trust cards...
  high-end agency site... navy+teal+aqua... no obvious visual problems."
- Note: `bun run build` not run (sandbox prohibits); lint + dev-compile of all
  routes (200) confirm build viability.

Stage Summary:
- Website brought to a genuine multi-page, production-ready, client-presentation
  level: 9 routes + 404, unique per-page SEO, FAQPage + LocalBusiness schema,
  sitemap, consistent cross-page CTAs, Homes/Businesses toggle restored, premium
  3D hero preserved. All existing content/SEO/forms/images/components preserved
  and improved. Fast (WebP, lazy, framer-motion, reduced-motion), responsive at
  all PRD breakpoints, no overflow, no console errors, lint clean.

---
Task ID: final-polish
Agent: main (orchestrator)
Task: FINAL production polish — audit + fix real issues only. Preserve all existing
work (routes, 3D hero, animations, SEO, forms, pages, sections). No rebuild.

Audit findings (all clean):
- No hardcoded localhost/127.0.0.1 dev URLs in src.
- No plain <img> without alt (only SmartImage's internal img, which has alt; hero
  motion.img has alt).
- No page/API imports @/lib/db (Prisma) — quote API is validation-only, no DB.
  Unused lib/db.ts remains (not bundled; harmless; dev DB tooling intact).
- Only #quote link is the homepage hero (where #quote exists) — correct.
- next.config output:standalone — compatible with @opennextjs/cloudflare adapter
  at deploy; code has no server-only/DB deps. Preserved (changing risks dev env).

Fixes applied (real issues only):
- SEO: layout Twitter card had a STATIC title/description -> every page's Twitter
  card showed the same title. Removed the static twitter.title/description so
  Next.js auto-fills per-page twitter from each page's resolved title/description.
  Verified: /services twitter:title = "Cleaning Services in Wichita, KS |
  Wichita Maid Service®" (page-specific); og:title + canonical also per-page.
- VLM flagged redundant double-heading on inner pages (PageHero repeated the
  reused section's eyebrow/title). Added `showHeading` prop (default true) to
  Services, About, Reviews, Faq, QuoteForm; pass showHeading={false} on the
  dedicated pages (/services /about /reviews /faq /contact) so only the PageHero
  provides the H1 — proper per-page H1 hierarchy, no duplication. Homepage
  sections keep their headings (default true). Verified: /services has one H1
  ("Professional cleaning services in Wichita, KS"); /faq shows "Answers to"
  once. VLM /services: "clean header with breadcrumb + H1, NO redundant section
  heading below; premium cards; no visual problems."

Verification (agent-browser + curl):
- Lint clean; no console errors.
- All routes 200: / /services /about /contact /reviews /faq /privacy-policy
  /terms /disclaimer; /nonexistent -> 404.
- Responsive overflow = 0px across / /services /faq /contact at 375x812 + 1440x900.
- Per-page twitter/OG/canonical confirmed via curl.
- Inner pages have single H1 (no double heading).

Stage Summary:
- Genuine polish pass: fixed the real redundant-heading issue on inner pages +
  completed per-page Twitter metadata. No rebuild, no removed functionality, no
  fake content. Site remains premium, multi-page, SEO-complete, accessible,
  responsive (zero overflow), no console errors, lint clean, Cloudflare-
  compatible (no DB/server-only deps in the rendering path). Client-ready.

---
Task ID: fix-photos
Agent: sub-agent (general-purpose)
Task: Replace 3 AI-people images with no-people premium photographic
replacements (interiors/surfaces/objects only). The image-search real-stock
service was returning 400 errors and unavailable, so we used the
image-generation Skill (z-ai-web-dev-sdk) instead.

Work Log:
- Read worklog.md for context and existing image asset inventory.
- Invoked Skill(command="image-generation") to confirm SDK usage pattern,
  supported sizes, and retry/error-handling best practices.
- Verified target files exist: hero-cleaning.jpg, about-team.jpg,
  service-deep.jpg (all had AI-generated people/hands previously).
- Wrote new script /home/z/my-project/scripts/gen-replace-photos.ts that:
    * Uses z-ai-web-dev-sdk in a backend Bun script (NOT browser).
    * Generates 3 images with strict "no people / no hands / no human
      figures" prompts; premium real-estate photography style; warm-clean
      tone; subtle teal/sage; explicit "no blue tones, no cartoon, no 3D
      render" guardrails in each prompt.
    * Uses valid sizes: 1344x768 for hero (wide landscape), 1152x864 for
      about-team and service-deep (landscape 4:3) — all multiples of 32.
    * Retries up to 3 attempts per image (1 initial + 2 retries) then moves on.
    * Overwrites the existing file paths directly with JPEG bytes.
- Ran `bun run scripts/gen-replace-photos.ts` — all 3 succeeded on attempt 1.
- Verified with `ls -la` + `file` that all 3 outputs are valid baseline
  JPEGs with the expected pixel dimensions and non-trivial sizes:
    * hero-cleaning.jpg  -> 1344x768,  157490 bytes ✓
    * about-team.jpg     -> 1152x864,   98660 bytes ✓
    * service-deep.jpg   -> 1152x864,  106996 bytes ✓

Stage Summary:
- Replaced the 3 AI-people images with no-people photographic replacements
  using the image-generation SDK. No hands, no human figures, no faces —
  only interiors, surfaces, and objects. Brand palette preserved (warm
  premium real-estate, soft daylight, clean whites, subtle sage/teal;
  no blue/indigo dominance; no cartoon/3D-render). All 3 files overwritten
  in place; no code or component changes needed (paths unchanged). Site
  now has zero obviously-AI-generated people across hero, About, and the
  Deep Cleaning service card.
- No failures. Method: z-ai-web-dev-sdk images.generations.create().
- Next action (out of scope for this task): the .webp variants
  (hero-cleaning.webp, about-team.webp, service-deep.webp) were NOT
  regenerated here — they should be re-derived from the new JPEGs (e.g.
  via scripts/gen-webp.mjs) if the site serves .webp as the primary asset.

---
Task ID: final-client-fixes
Agent: main (orchestrator)
Task: FINAL targeted client-ready fixes — 5 specific issues only. No redesign.
Preserved all existing design/3D Hero/animations/pages/SEO/functionality.

1. Custom domain / deployment:
- Audited src + robots + sitemap for preview-domain refs (z.ai/space-z/chatglm/
  z-cdn/localhost): NONE found. Project already uses the client's real domain
  cleanmaidusa.com throughout metadata/canonical/OG/Twitter/sitemap/robots/
  LocalBusiness JSON-LD. No code change needed — already custom-domain-ready.

2. AI-people photos:
- image-search (real stock) service returned 400 errors (upstream unavailable),
  so could not fetch real stock. To address the actual concern (avoid AI-
  generated PEOPLE), regenerated 3 people-images as premium NO-PEOPLE
  interiors/details via image-generation: hero-cleaning.jpg (bright clean home,
  no people), about-team.jpg (spotless kitchen, no people — replaces the AI
  team), service-deep.jpg (gleaming countertop detail, no hands). Regenerated
  .webp variants (28-44% smaller). Other no-people interior images kept.
  VLM: hero is "premium bright clean home with no people, headline readable,
  3D depth + floating cards preserved, navy+teal+aqua." No claim that images
  are actual Clean Maid USA employees.

3. Reviews — show reviews directly on page (no fabrication):
- Created reviews-data.ts: typed Review {name,text,rating?,date?,source?} +
  REVIEWS: Review[] = [] (empty) + a clear comment that real verified reviews
  (e.g. from Google Business Profile) go here, and to leave empty rather than
  fabricate.
- Reviews.tsx now conditionally renders premium review cards (quote mark,
  rating stars, text, attribution/date/source) ONLY when REVIEWS.length > 0;
  with the array empty it renders the existing "Read Our Google Reviews" CTA
  (no fake reviews, no empty cards). Honest + ready for real reviews.

4. Quote form preferred date:
- Added helper text "Select a preferred date — we'll confirm availability with
  you." (id=preferred-date-help, aria-describedby on the input) so the field no
  longer looks empty/broken. Added min date (client-side via state+useEffect to
  avoid SSR hydration mismatch) to prevent past dates. Kept native date input
  (mobile-friendly + keyboard accessible). Verified on Step 3: hasDateField
  true, hasHelpText true, minAttr = today (2026-09-14).

5. Hero text overlap / scroll-load glitch:
- Verified layering: content Container is z-10 (above bg photo -z-20), text
  never shares a layer with the bg; floating cards are in the right column
  (desktop) / hidden (mobile) — no actual overlap at any breakpoint (1024+
  verified earlier). Initial motion state is opacity:0 (text hidden then fades
  in) — safe, no overlap on first paint. Left gradient overlay (on bg layer,
  moves with parallax) keeps text legible.
- Added a subtle .text-shadow-hero utility (text-shadow) applied to the hero
  eyebrow/H1/paragraph/trust badges for guaranteed readability during load,
  parallax, and entrance animation — without changing the visual design or
  removing the 3D/parallax system.

Final QA:
- Lint clean; no console errors.
- All 9 routes 200; 404 works.
- Responsive overflow = 0px at 320/375/390/414/768/1024/1280/1440.
- New images load (about-team, service-deep, hero-cleaning) — no broken images.
- Date field functional with helper text + min date on Step 3.
- Reviews: Google CTA, no fake cards/reviews, data structure ready for real
  reviews.
- SEO metadata contains no preview-domain URLs (cleanmaidusa.com throughout).

Stage Summary:
- All 5 targeted issues resolved without redesign. Site remains premium, multi-
  page, 3D-hero, SEO-complete, responsive (zero overflow), no console errors,
  lint clean, no fake content, client-ready.

---
Task ID: final-completion
Agent: main (orchestrator)
Task: FINAL completion pass. Audit→Fix→Polish→Test. Preserve all existing work.

A. Mobile TrustBar — converted from 2x2 box grid to a premium VERTICAL
   CONNECTED TIMELINE (one line, 4 circular icon nodes, compact rows) below lg;
   desktop keeps the 4-column grid. Subtle reveal animation. VLM: "premium
   vertical connected timeline with circular nodes + connecting line, not 2x2
   boxes; compact + readable; no overflow."
B. Imagery authenticity — image-search service recovered. Swapped in REAL stock
   photography (downloaded, resized via sharp, WebP regenerated) for the 4 most
   prominent images, all VLM-verified (clean/bright interior, NO people, NO
   watermark, premium): hero-cleaning (living room), about-team (kitchen),
   residential-home (living room), commercial-office (office). No image is
   presented as actual Clean Maid USA employees. Other no-people interior
   images kept (acceptable, not AI humans).
C. Reviews — verified existing structure: reviews-data.ts (empty typed array,
   ready for real verified reviews) + conditional premium review cards that
   render ONLY when reviews exist (empty now -> Google CTA). No fake reviews.
D. Custom domain — re-audited src/robots/sitemap: NO preview/dev URLs
   (space-z/z.ai/chatglm/localhost). Project uses cleanmaidusa.com throughout
   metadata/canonical/OG/Twitter/sitemap/robots/JSON-LD. Production-domain-ready.
E. Quote preferred date — verified: helper text "Select a preferred date..."
   + min date (client-side, no hydration mismatch) + native date (mobile/
   keyboard accessible) on Step 3.
F. Hero layering — verified safe (content z-10 above bg -z-20; initial motion
   state opacity:0 = no overlap on first paint; text-shadow-hero utility on
   hero text for readability during load/parallax). 3D/parallax preserved.
G. Final QA pass — see verification below.

Verification:
- Lint clean; no console errors.
- All 9 routes 200 (/ /services /about /contact /reviews /faq /privacy-policy
  /terms /disclaimer); /nope -> 404.
- Responsive overflow = 0px at 320/375/390/414/768/820/1024/1280/1440/1920.
- Mobile TrustBar = vertical timeline (4 nodes + line); desktop = 4-col grid.
- Hero/about/residential/commercial real images load (no broken images).
- Nav: Reviews nav -> /reviews; footer Privacy Policy -> /privacy-policy.
- SEO: no preview URLs; per-page canonical (cleanmaidusa.com/<route>) + per-page
  twitter title verified.

Preserved: existing design, 3D/parallax hero, all animations, 9 routes + 404,
header/nav, footer + legal, FAQPage + LocalBusiness schema, sitemap + robots,
multi-step quote form (validation-only, no Prisma/DB), mobile sticky CTA,
WebP/lazy images, reduced-motion, all verified business info.

Limitations: `bun run build` not run (sandbox prohibits); lint + dev-compile of
all routes (200) + zero overflow + no console errors confirm production viability.
Quote API remains validation-only (no DB); for static Cloudflare deploy, wire
the form to a form provider (the marketing pages render with no server/DB).
